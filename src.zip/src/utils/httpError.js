/** `extra` lets a throw site carry flags the frontend's interceptor checks for (maintenance, readOnly). */
class HttpError extends Error {
  constructor(status, message, extra) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

/** Every success response follows the frontend's `{ success, data, ... }` envelope — see store/api.ts. */
const ok = (res, status, data, extra = {}) => res.status(status).json({ success: true, data, ...extra });
const okMessage = (res, status, message, extra = {}) => res.status(status).json({ success: true, message, ...extra });

module.exports = { HttpError, asyncHandler, ok, okMessage };
