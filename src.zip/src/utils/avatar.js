/**
 * Section 1 (v6) — Universal Avatar & Cartoon Fallback Rule.
 * Every person record gets an `avatarUrl`. If they've uploaded a photo, that wins; otherwise
 * we derive a stable, friendly illustrated-avatar URL from their id, so the same person always
 * gets the same cartoon (never blank initials, never a broken image icon).
 */
const cartoonFallback = (seed) =>
  `https://api.dicebear.com/9.x/notionists/svg?seed=${encodeURIComponent(seed)}&backgroundType=gradientLinear`;

const withAvatar = (person) => ({
  ...person,
  avatarUrl: person.photoUrl || cartoonFallback(person._id || person.email || person.firstName || "yare"),
});

module.exports = { withAvatar, cartoonFallback };
