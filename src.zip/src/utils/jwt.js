const jwt = require("jsonwebtoken");
const { JWT_SECRET, JWT_EXPIRES_IN } = require("../config/env");

const signToken = (payload, expiresIn = JWT_EXPIRES_IN) => jwt.sign(payload, JWT_SECRET, { expiresIn });
const verifyToken = (token) => jwt.verify(token, JWT_SECRET);

module.exports = { signToken, verifyToken };
