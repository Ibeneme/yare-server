const { HttpError } = require("../utils/httpError");

/** requireRole("admin", "superadmin") — call after requireAuth. */
const requireRole = (...roles) => (req, res, next) => {
  if (!req.user) return next(new HttpError(401, "Not authenticated"));
  if (!roles.includes(req.user.role)) {
    return next(new HttpError(403, "You don't have permission to do that"));
  }
  next();
};

module.exports = { requireRole };
