const { STAFF_USER_TYPES } = require("../config/constants");
const { getSettings } = require("../services/settings.service");

// Blocking maintenance window: only staff (userType "admin", which covers superadmin too) can
// keep working; everyone else gets a 503 the frontend's axios interceptor recognizes via
// `body.maintenance === true` (see lib/axiosInstance.ts) and shows as a banner.
const maintenanceGate = (req, res, next) => {
  const settings = getSettings();
  if (!settings.maintenanceMode) return next();
  if (req.user && STAFF_USER_TYPES.includes(req.user.userType)) return next();
  if (req.path === "/health") return next();

  return res.status(503).json({
    success: false,
    maintenance: true,
    message: settings.maintenanceMessage || "Yare Height is undergoing scheduled maintenance. Please check back shortly.",
  });
};

module.exports = { maintenanceGate };
