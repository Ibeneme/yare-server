const { verifyToken } = require("../utils/jwt");
const { HttpError } = require("../utils/httpError");
const { findAccountById, roleFor } = require("../services/account.service");

/** Verifies the bearer JWT and attaches req.user = { _id, userType, role, account }. */
const requireAuth = (req, res, next) => {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) throw new HttpError(401, "Not authenticated");

    const payload = verifyToken(token);
    if (payload.purpose && payload.purpose !== "session") throw new HttpError(401, "Not authenticated");
    const account = findAccountById(payload.id, payload.userType);
    if (!account) throw new HttpError(401, "Account no longer exists");

    req.user = { _id: account._id, userType: payload.userType, role: roleFor(account, payload.userType), account };
    next();
  } catch (_err) {
    next(new HttpError(401, "Not authenticated"));
  }
};

const optionalAuth = (req, res, next) => {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return next();
  try {
    const payload = verifyToken(token);
    if (payload.purpose && payload.purpose !== "session") return next();
    const account = findAccountById(payload.id, payload.userType);
    if (account) req.user = { _id: account._id, userType: payload.userType, role: roleFor(account, payload.userType), account };
  } catch (_err) {
    /* ignore bad/expired token for optional auth */
  }
  next();
};

/** For POST /reset-password, where the frontend sends the OTP-issued reset token as the bearer. */
const requireResetToken = (req, res, next) => {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : null;
    if (!token) throw new HttpError(401, "Missing reset token");
    const payload = verifyToken(token);
    if (payload.purpose !== "reset") throw new HttpError(401, "Invalid reset token");
    req.resetPayload = payload;
    next();
  } catch (_err) {
    next(new HttpError(401, "Reset token is invalid or expired"));
  }
};

module.exports = { requireAuth, optionalAuth, requireResetToken };
