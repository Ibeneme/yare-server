const { USER_TYPES } = require("../config/constants");
const { db } = require("../state");
const { computeAccess } = require("../services/access.service");

// Section 3 — Silent Child Read-Only Mode: once access lapses, a student can still view past
// materials but cannot join live classes or submit assignments. Neutral wording only — never a
// fee/billing mention. The frontend's axios interceptor looks for `status===403 && body.readOnly`
// (see lib/axiosInstance.ts) to show its own neutral banner, so we match that exactly here.
const BLOCKED_WHEN_READ_ONLY = [
  { method: "POST", test: (path) => /\/classroom\/.+\/join$/.test(path) },
  { method: "POST", test: (path) => /\/classroom\/assignments\/.+\/submit$/.test(path) },
];

const studentReadOnlyGuard = (req, res, next) => {
  if (!req.user || req.user.userType !== USER_TYPES.STUDENT) return next();

  const student = db.students.findById(req.user._id);
  if (!student) return next();
  const access = computeAccess(student);
  if (access.mode !== "read_only") return next();

  const isBlocked = BLOCKED_WHEN_READ_ONLY.some((rule) => rule.method === req.method && rule.test(req.path));
  if (!isBlocked) return next();

  return res.status(403).json({
    success: false,
    readOnly: true,
    message: "This is view-only right now. Live sessions and new submissions aren't available at the moment.",
  });
};

module.exports = { studentReadOnlyGuard };
