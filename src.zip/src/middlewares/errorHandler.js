const notFound = (req, res) => res.status(404).json({ success: false, message: "Not found" });

/** Matches store/models.ts' ApiErrorBody: { success:false, message, error?, maintenance?, readOnly? }. */
const errorHandler = (err, req, res, _next) => {
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({
    success: false,
    message: err.message || "Something went wrong",
    ...(err.extra || {}),
  });
};

module.exports = { notFound, errorHandler };
