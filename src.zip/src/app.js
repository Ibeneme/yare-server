const express = require("express");
const cors = require("cors");
const { CORS_ORIGINS } = require("./config/env");
const routes = require("./routes");
const { notFound, errorHandler } = require("./middlewares/errorHandler");
const { optionalAuth } = require("./middlewares/auth.middleware");
const { studentReadOnlyGuard } = require("./middlewares/studentAccess.middleware");
const { maintenanceGate } = require("./middlewares/maintenance.middleware");
const { rooms } = require("./sockets/roomState");

const createApp = () => {
  const app = express();

  app.use(
    cors({
      origin: (origin, callback) => {
        if (!origin) return callback(null, true); // mobile apps, curl, Postman
        if (CORS_ORIGINS.includes("*") || CORS_ORIGINS.includes(origin)) return callback(null, true);
        callback(new Error("Not allowed by CORS"));
      },
      credentials: true,
    }),
  );

  // Capture the raw body on every request — the Paystack webhook (routes/payments.routes.js)
  // needs the exact raw bytes to verify its HMAC signature, not a re-serialized copy.
  app.use(express.json({ limit: "2mb", verify: (req, _res, buf) => { req.rawBody = buf; } }));
  app.use(express.urlencoded({ extended: true }));

  app.get("/health", (req, res) => res.json({ ok: true, rooms: Object.keys(rooms).length }));

  app.use(optionalAuth); // so maintenance/read-only gates can see req.user without forcing login
  app.use(maintenanceGate); // blocking maintenance window: Super Admin/Admin only
  app.use(studentReadOnlyGuard); // read-only students: neutral block on join/submit only
  app.use(routes);

  app.use(notFound);
  app.use(errorHandler);
  return app;
};

module.exports = { createApp };
