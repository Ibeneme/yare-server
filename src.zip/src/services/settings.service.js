const { db } = require("../state");
const { DEFAULT_TRIAL_DAYS } = require("../config/constants");

const SETTINGS_ID = "platform-settings";

const defaults = {
  _id: SETTINGS_ID,
  trialEnabled: true,
  trialDays: DEFAULT_TRIAL_DAYS,
  maintenanceMode: false,
  maintenanceMessage: "",
};

const getSettings = () => db.platformSettings.findById(SETTINGS_ID) || db.platformSettings.insert(defaults);
const updateSettings = (patch) => {
  getSettings();
  return db.platformSettings.update(SETTINGS_ID, patch);
};

/** Shape the frontend's PlatformSettings type expects: `{ trial: { enabled, days } }`. */
const toPublicSettings = (settings) => ({ trial: { enabled: settings.trialEnabled, days: settings.trialDays } });

module.exports = { getSettings, updateSettings, toPublicSettings, SETTINGS_ID };
