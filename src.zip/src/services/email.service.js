const nodemailer = require("nodemailer");
const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, MAIL_FROM, NODE_ENV } = require("../config/env");

let transporter = null;
const getTransporter = () => {
  if (transporter) return transporter;
  if (!SMTP_HOST) return null; // no SMTP configured — we log instead (fine for dev/trial envs)
  transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: SMTP_PORT,
    secure: SMTP_PORT === 465,
    auth: SMTP_USER ? { user: SMTP_USER, pass: SMTP_PASS } : undefined,
  });
  return transporter;
};

const sendMail = async ({ to, subject, html }) => {
  const t = getTransporter();
  if (!t) {
    if (NODE_ENV !== "test") console.log(`[email:dry-run] to=${to} subject="${subject}"`);
    return { dryRun: true };
  }
  return t.sendMail({ from: MAIL_FROM, to, subject, html });
};

module.exports = { sendMail };
