const { db, resetAll } = require("../state");
const { ROLES } = require("../config/constants");
const { hashPassword } = require("../utils/password");
const { SUPER_ADMIN_EMAIL, SUPER_ADMIN_PASSWORD } = require("../config/env");

/**
 * Section 1 — Single Hardcoded Super Admin.
 * On every boot: wipe all in-memory state (there is no external DB to persist it anyway),
 * then create exactly one Super Admin account. Nothing else exists until it provisions people.
 */
const seedSuperAdmin = async () => {
  //resetAll();

  db.admins.insert({
    role: ROLES.SUPER_ADMIN,
    firstName: "Super",
    lastName: "Admin",
    email: SUPER_ADMIN_EMAIL,
    passwordHash: hashPassword(SUPER_ADMIN_PASSWORD),
    isSuspended: false,
    photoUrl: null,
  });

  console.log(`Super Admin seeded: ${SUPER_ADMIN_EMAIL}`);
};

module.exports = { seedSuperAdmin };
