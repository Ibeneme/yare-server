const { db } = require("../state");
const { SUBSCRIPTION_STATUS, FEE_REMINDER_DAYS, GRACE_OPTIONS, DEFAULT_TRIAL_DAYS } = require("../config/constants");
const { getSettings } = require("./settings.service");

const addDays = (date, days) => new Date(date.getTime() + days * 86400000);
const addMonths = (date, months) => {
  const d = new Date(date);
  d.setMonth(d.getMonth() + months);
  return d;
};
const endOfMonth = (date) => new Date(date.getFullYear(), date.getMonth() + 1, 0, 23, 59, 59);

const getSubscriptionForStudent = (studentId) => db.subscriptions.findOne((s) => s.studentId === studentId);

/** Section 4 — every newly registered student gets an automatic free trial (if enabled). */
const startTrialForStudent = (studentId) => {
  const settings = getSettings();
  const days = settings.trialEnabled ? settings.trialDays || DEFAULT_TRIAL_DAYS : 0;
  const now = new Date();
  const record = {
    studentId,
    status: settings.trialEnabled ? SUBSCRIPTION_STATUS.TRIAL : SUBSCRIPTION_STATUS.READ_ONLY,
    trialDays: days,
    trialEndsAt: settings.trialEnabled ? addDays(now, days).toISOString() : null,
    expiresAt: null,
    graceDeadline: null,
    adminGraceUntil: null,
    currency: null,
    planLabel: null,
  };
  const existing = getSubscriptionForStudent(studentId);
  return existing ? db.subscriptions.update(existing.id, record) : db.subscriptions.insert(record);
};

/** Called after a successful Paystack payment — Section 3 "Pricing & Checkout". */
const activateSubscription = (studentId, { currency, planLabel, months = 1 }) => {
  const now = new Date();
  const sub = getSubscriptionForStudent(studentId) || db.subscriptions.insert({ studentId });
  return db.subscriptions.update(sub.id, {
    status: SUBSCRIPTION_STATUS.ACTIVE,
    currency,
    planLabel,
    expiresAt: addMonths(now, months).toISOString(),
    graceDeadline: null,
    adminGraceUntil: null,
  });
};

/** Admin Grace Override Toggle — Section 3. presetKey is one of GRACE_OPTIONS' keys. */
const applyAdminGrace = (studentId, presetKey) => {
  const preset = GRACE_OPTIONS[presetKey];
  if (!preset) throw new Error("Unknown grace preset");
  const now = new Date();
  const until = preset.days ? addDays(now, preset.days) : addMonths(now, preset.months);
  const sub = getSubscriptionForStudent(studentId) || db.subscriptions.insert({ studentId });
  return db.subscriptions.update(sub.id, {
    status: SUBSCRIPTION_STATUS.ADMIN_GRACE,
    adminGraceUntil: until.toISOString(),
  });
};

/**
 * Section 3 — the lifecycle state machine. Run for every student subscription, typically from
 * a daily cron tick (see jobs/subscriptionExpiry.job.js), but also safe to call on demand.
 * trial/active -> grace (on expiry) -> read_only (once the grace window fully closes).
 */
const reconcileStatus = (sub) => {
  const now = new Date();

  if (sub.status === SUBSCRIPTION_STATUS.ADMIN_GRACE) {
    if (sub.adminGraceUntil && now < new Date(sub.adminGraceUntil)) return sub; // still covered
    return db.subscriptions.update(sub.id, { status: SUBSCRIPTION_STATUS.GRACE, graceDeadline: computeGraceDeadline(now) });
  }

  if (sub.status === SUBSCRIPTION_STATUS.TRIAL) {
    if (sub.trialEndsAt && now >= new Date(sub.trialEndsAt)) {
      return db.subscriptions.update(sub.id, { status: SUBSCRIPTION_STATUS.GRACE, graceDeadline: computeGraceDeadline(now) });
    }
    return sub;
  }

  if (sub.status === SUBSCRIPTION_STATUS.ACTIVE) {
    if (sub.expiresAt && now >= new Date(sub.expiresAt)) {
      return db.subscriptions.update(sub.id, { status: SUBSCRIPTION_STATUS.GRACE, graceDeadline: computeGraceDeadline(now) });
    }
    return sub;
  }

  if (sub.status === SUBSCRIPTION_STATUS.GRACE) {
    if (sub.graceDeadline && now >= new Date(sub.graceDeadline)) {
      return db.subscriptions.update(sub.id, { status: SUBSCRIPTION_STATUS.READ_ONLY });
    }
    return sub;
  }

  return sub; // READ_ONLY stays until renewed (activateSubscription resets it)
};

// Access stays full through 14 days post-expiry OR the end of the expiry month — whichever is later.
const computeGraceDeadline = (expiredAt) => {
  const byDays = addDays(expiredAt, FEE_REMINDER_DAYS);
  const byMonthEnd = endOfMonth(expiredAt);
  return (byDays > byMonthEnd ? byDays : byMonthEnd).toISOString();
};

const daysRemainingInGrace = (sub) => {
  if (!sub.graceDeadline) return 0;
  const ms = new Date(sub.graceDeadline) - new Date();
  return Math.max(0, Math.ceil(ms / 86400000));
};

module.exports = {
  getSubscriptionForStudent,
  startTrialForStudent,
  activateSubscription,
  applyAdminGrace,
  reconcileStatus,
  daysRemainingInGrace,
};
