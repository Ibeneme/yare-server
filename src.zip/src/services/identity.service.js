const { db } = require("../state");
const { USER_TYPES, ROLES } = require("../config/constants");
const { hashPassword, comparePassword } = require("../utils/password");
const { signToken } = require("../utils/jwt");
const { generateOtp } = require("../utils/otp");
const { sendMail } = require("./email.service");
const { collectionForUserType, toPublic, roleFor } = require("./account.service");
const { trialFieldsForNewStudent } = require("./access.service");

const OTP_TTL_MS = 10 * 60 * 1000;

const sessionToken = (account, userType) => signToken({ id: account._id, userType, purpose: "session" });

/** Shapes a newly-created record per userType, applying the right defaults (Section 1/2). */
const buildNewAccount = (userType, fields) => {
  const base = {
    firstName: fields.firstName,
    lastName: fields.lastName,
    email: fields.email,
    passwordHash: fields.password ? hashPassword(fields.password) : null,
    isSuspended: false,
    photoUrl: null,
  };
  if (userType === USER_TYPES.ADMIN) {
    return { ...base, role: fields.asSuperAdmin ? ROLES.SUPER_ADMIN : ROLES.ADMIN };
  }
  if (userType === USER_TYPES.TEACHER) {
    return {
      ...base,
      classIds: [],
      subjectIds: [],
      gradeIds: [],
      certifications: fields.certifications || [],
      skills: fields.skills || [],
      languages: fields.languages || [],
      educationBackground: fields.educationBackground || "",
      inClass: false,
      reported: false,
    };
  }
  if (userType === USER_TYPES.PARENT) {
    return { ...base, phoneNumber: fields.phoneNumber || fields.phone || "", children: [], isVerified: false, reported: false };
  }
  // student
  return {
    ...base,
    parentId: fields.parentId || null,
    gradeId: fields.gradeId || null,
    subjects: fields.subjects || [],
    languages: fields.languages || [],
    skills: fields.skills || [],
    isSuspended: false,
    inClass: false,
    isPaid: false,
    isSubscribed: false,
    lessonFeeId: null,
    adminGraceUntil: null,
    adminGraceDuration: null,
    subscriptionExpiredAt: null,
    expiryGraceEndsAt: null,
    ...trialFieldsForNewStudent(),
  };
};

const createAccount = (userType, fields) => {
  const account = collectionForUserType(userType).insert(buildNewAccount(userType, fields));
  if (userType === USER_TYPES.STUDENT && fields.parentId) {
    const parent = db.parents.findById(fields.parentId);
    if (parent) db.parents.update(parent._id, { children: [...parent.children, account._id] });
  }
  return account;
};

const login = (userType, email, password) => {
  const account = collectionForUserType(userType).findOne((u) => (u.email || "").toLowerCase() === String(email).toLowerCase());
  if (!account || account.isSuspended) return null;
  if (!account.passwordHash || !comparePassword(password, account.passwordHash)) return null;
  return { account, token: sessionToken(account, userType) };
};

/** One OTP store doubles for registration-verification and forgot-password — purpose tells them apart. */
const startOtp = async ({ email, userType, purpose, payload, subject }) => {
  const otp = generateOtp();
  const existing = db.pendingRegistrations.findOne((r) => r.email === email && r.purpose === purpose);
  const record = { email, userType, purpose, payload: payload || null, otp, otpExpiresAt: Date.now() + OTP_TTL_MS };
  if (existing) db.pendingRegistrations.update(existing._id, record);
  else db.pendingRegistrations.insert(record);

  await sendMail({ to: email, subject, html: `<p>Your Yare Height verification code is <strong>${otp}</strong>. It expires in 10 minutes.</p>` });
  return otp;
};

const verifyOtp = (email, otp, purpose) => {
  const record = db.pendingRegistrations.findOne((r) => r.email === email && r.purpose === purpose);
  if (!record) return null;
  if (record.otp !== String(otp)) return null;
  if (Date.now() > record.otpExpiresAt) return null;
  return record;
};

const consumeOtp = (recordId) => db.pendingRegistrations.delete(recordId);

const resetToken = (email, userType) => signToken({ email, userType, purpose: "reset" }, "15m");

module.exports = {
  buildNewAccount,
  createAccount,
  login,
  sessionToken,
  startOtp,
  verifyOtp,
  consumeOtp,
  resetToken,
  toPublic,
  roleFor,
};
