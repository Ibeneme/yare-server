const crypto = require("crypto");
const { PAYSTACK_SECRET_KEY, PAYSTACK_BASE_URL } = require("../config/env");

/** Initializes a Paystack checkout. Amounts are in the currency's smallest unit (kobo/cents). */
const initializeCheckout = async ({ email, amountMinorUnits, currency, metadata, callbackUrl }) => {
  if (!PAYSTACK_SECRET_KEY) {
    // No live key configured (dev/trial env) — return a mock reference so the flow still works end to end.
    return { authorizationUrl: callbackUrl, reference: `mock_${Date.now()}`, mock: true };
  }
  const res = await fetch(`${PAYSTACK_BASE_URL}/transaction/initialize`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email,
      amount: amountMinorUnits,
      currency,
      metadata,
      callback_url: callbackUrl,
    }),
  });
  const json = await res.json();
  if (!json.status) throw new Error(json.message || "Paystack initialization failed");
  return {
    authorizationUrl: json.data.authorization_url,
    reference: json.data.reference,
    accessCode: json.data.access_code,
  };
};

/** Re-checks a transaction's status directly with Paystack (used by the verify endpoint, mirroring the webhook). */
const verifyTransaction = async (reference) => {
  if (!PAYSTACK_SECRET_KEY || reference.startsWith("mock_")) return { status: "success", mock: true };
  const res = await fetch(`${PAYSTACK_BASE_URL}/transaction/verify/${encodeURIComponent(reference)}`, {
    headers: { Authorization: `Bearer ${PAYSTACK_SECRET_KEY}` },
  });
  const json = await res.json();
  if (!json.status) throw new Error(json.message || "Paystack verification failed");
  return { status: json.data.status, raw: json.data };
};

/** Section 3 — signature-verified webhooks. Paystack signs the *raw* request body with HMAC-SHA512. */
const verifyWebhookSignature = (rawBody, signatureHeader) => {
  if (!PAYSTACK_SECRET_KEY) return true; // mock mode
  const hash = crypto.createHmac("sha512", PAYSTACK_SECRET_KEY).update(rawBody).digest("hex");
  return hash === signatureHeader;
};

module.exports = { initializeCheckout, verifyTransaction, verifyWebhookSignature };
