const { db } = require("../state");
const { COLLECTION_FOR_USER_TYPE, ROLES, USER_TYPES } = require("../config/constants");
const { withAvatar } = require("../utils/avatar");

const collectionForUserType = (userType) => db[COLLECTION_FOR_USER_TYPE[userType] || "students"];

const findAccountById = (id, userType) => collectionForUserType(userType).findById(id);

/** Searches every collection by email (used at login, where the caller already states userType,
 * but also by forgot-password/legacy lookups that only have an email). */
const findAccountByEmail = (email, userType) => {
  const lower = String(email || "").toLowerCase();
  if (userType) return collectionForUserType(userType).findOne((u) => (u.email || "").toLowerCase() === lower);
  for (const type of Object.values(USER_TYPES)) {
    const hit = collectionForUserType(type).findOne((u) => (u.email || "").toLowerCase() === lower);
    if (hit) return { account: hit, userType: type };
  }
  return null;
};

/** The server role: userType "admin" records carry their own `role` (admin|superadmin); everyone else's role equals their userType. */
const roleFor = (account, userType) => (userType === USER_TYPES.ADMIN ? account.role || ROLES.ADMIN : userType);

/** Strips the password hash and attaches the universal avatar fallback before anything leaves the API. */
const toPublic = (account) => {
  if (!account) return account;
  const { passwordHash, otp, otpExpiresAt, ...rest } = account;
  return withAvatar(rest);
};

module.exports = { collectionForUserType, findAccountById, findAccountByEmail, roleFor, toPublic };
