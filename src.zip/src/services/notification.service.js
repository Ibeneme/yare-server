const { db } = require("../state");

const modelFor = (userType) => ({ admin: "Admin", teacher: "Teacher", student: "Student", parent: "Parent" }[userType] || "Student");

const getPrefs = (userId) => db.notificationPrefs.findById(userId);

/** Creates an in-app AppNotification, respecting the parent's own alert-trigger preferences. */
const notify = ({ userId, userType, type, title, message, meta = {} }) => {
  if (userType === "parent") {
    const prefs = getPrefs(userId);
    const typeToPrefKey = { class_reminder: "classReminders", billing: "feeNotices", award: "awards" };
    const prefKey = typeToPrefKey[type];
    if (prefKey && prefs && prefs[prefKey] === false) return null;
  }
  return db.notifications.insert({
    title,
    description: message,
    recipient: userId,
    recipientModel: modelFor(userType),
    type,
    isRead: false,
    meta,
  });
};

module.exports = { notify, getPrefs };
