const { db } = require("../state");
const { AWARD_PERK_TYPES } = require("../config/constants");
const { activateSubscription, getSubscriptionForStudent } = require("./subscription.service");
const { notify } = require("./notification.service");
const { sendMail } = require("./email.service");
const { awardNotificationEmail } = require("../templates/notices.template");

const createTemplate = ({ title, description, perkType, perkValue }) =>
  db.awardTemplates.insert({ title, description, perkType, perkValue: perkValue ?? null });

const listTemplates = () => db.awardTemplates.all();

/** Section 5 — issuing an award applies its perk automatically, then notifies student + parent. */
const issueAward = async ({ templateId, studentId, parent, student, issuedByUserId }) => {
  const template = db.awardTemplates.findById(templateId);
  if (!template) throw new Error("Award template not found");

  const grant = db.awardGrants.insert({
    templateId,
    studentId,
    issuedByUserId,
    perkApplied: false,
    perkType: template.perkType,
  });

  let perkLabel = "";
  if (template.perkType === AWARD_PERK_TYPES.FREE_MONTH) {
    const sub = getSubscriptionForStudent(studentId);
    activateSubscription(studentId, {
      currency: sub?.currency || "NGN",
      planLabel: sub?.planLabel || "Free month (award)",
      months: 1,
    });
    perkLabel = "a free month was added to the subscription";
  } else if (template.perkType === AWARD_PERK_TYPES.DISCOUNT_50) {
    db.awardGrants.update(grant.id, { discountPercent: 50, redeemedAt: null });
    perkLabel = "a 50% discount is ready for the next checkout";
  } else {
    perkLabel = template.description || "a custom perk";
  }
  db.awardGrants.update(grant.id, { perkApplied: true });

  if (student) notify({ userId: studentId, role: "student", type: "award", title: template.title, message: perkLabel });
  if (parent) {
    notify({ userId: parent.id, role: "parent", type: "award", title: template.title, message: perkLabel });
    await sendMail({
      to: parent.email,
      subject: `${student?.firstName || "Your child"} just earned an award!`,
      html: awardNotificationEmail({
        parentName: parent.firstName,
        studentName: student?.firstName,
        awardTitle: template.title,
        perkLabel,
      }),
    });
  }

  return grant;
};

const listGrantsForStudent = (studentId) => db.awardGrants.find((g) => g.studentId === studentId);

module.exports = { createTemplate, listTemplates, issueAward, listGrantsForStudent };
