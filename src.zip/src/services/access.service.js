const { FEE_REMINDER_DAYS, GRACE_DURATIONS, DEFAULT_TRIAL_DAYS } = require("../config/constants");
const { getSettings } = require("./settings.service");

const addDays = (date, days) => new Date(date.getTime() + days * 86400000);
const addMonths = (date, months) => {
  const d = new Date(date);
  d.setMonth(d.getMonth() + months);
  return d;
};
const endOfMonth = (date) => new Date(date.getFullYear(), date.getMonth() + 1, 0, 23, 59, 59);
const daysBetween = (a, b) => Math.max(0, Math.ceil((new Date(a) - new Date(b)) / 86400000));

/** Section 4 — every newly registered student gets an automatic free trial (if enabled). Mutates the given student patch object (caller persists it). */
const trialFieldsForNewStudent = () => {
  const settings = getSettings();
  const now = new Date();
  if (!settings.trialEnabled) return { trialEndsAt: null, trialDays: 0 };
  const days = settings.trialDays || DEFAULT_TRIAL_DAYS;
  return { trialEndsAt: addDays(now, days).toISOString(), trialDays: days };
};

/** Section 3 — the AccessState state machine, computed straight from the student's own fields
 * (trialEndsAt/trialDays/subscriptionExpiredAt/expiryGraceEndsAt/adminGraceUntil/adminGraceDuration),
 * which is exactly how store/models.ts' Student type carries it. */
const computeAccess = (student) => {
  const now = new Date();

  if (student.adminGraceUntil && now < new Date(student.adminGraceUntil)) {
    return { mode: "full", reason: "admin_grace", until: student.adminGraceUntil };
  }

  if (student.subscriptionExpiredAt) {
    const expiredAt = new Date(student.subscriptionExpiredAt);
    if (now < expiredAt) return { mode: "full", reason: "paid", until: student.subscriptionExpiredAt };
    if (student.expiryGraceEndsAt && now < new Date(student.expiryGraceEndsAt)) {
      return { mode: "full", reason: "expiry_grace", until: student.expiryGraceEndsAt, since: student.subscriptionExpiredAt };
    }
    return { mode: "read_only", reason: "lapsed", since: student.subscriptionExpiredAt };
  }

  if (student.trialEndsAt) {
    const trialEnds = new Date(student.trialEndsAt);
    if (now < trialEnds) return { mode: "full", reason: "trial", until: student.trialEndsAt };
    return { mode: "read_only", reason: "trial_ended", since: student.trialEndsAt };
  }

  return { mode: "read_only", reason: "not_subscribed" };
};

/** What the student themself is shown — never mentions fees (Section 3's "Crucial Rule"). */
const toStudentView = (access) => ({
  mode: access.mode,
  readOnly: access.mode === "read_only",
  message: access.mode === "read_only" ? "This is view-only right now. Live sessions and new submissions aren't available at the moment." : null,
});

const daysLeft = (access) => (access.until ? daysBetween(access.until, new Date()) : null);
const needsRenewal = (access) => access.reason !== "paid" && access.mode === "full" ? true : access.mode === "read_only";

/** Called after a successful payment — Section 3 "Pricing & Checkout". Returns the student patch to apply. */
const activateSubscriptionPatch = ({ months = 1 }) => {
  const now = new Date();
  return {
    isPaid: true,
    isSubscribed: true,
    subscriptionExpiredAt: addMonths(now, months).toISOString(),
    expiryGraceEndsAt: null,
    adminGraceUntil: null,
    adminGraceDuration: null,
  };
};

/** Admin Grace Override Toggle — Section 3. */
const adminGracePatch = (durationKey) => {
  const preset = GRACE_DURATIONS[durationKey];
  if (!preset) throw new Error("Unknown grace duration");
  const now = new Date();
  const until = preset.days ? addDays(now, preset.days) : addMonths(now, preset.months);
  return { adminGraceUntil: until.toISOString(), adminGraceDuration: durationKey };
};

/** Ensures expiryGraceEndsAt is set once a subscription has just lapsed (14 days, or to month-end if later). */
const ensureExpiryGrace = (student) => {
  if (!student.subscriptionExpiredAt || student.expiryGraceEndsAt) return null;
  const expiredAt = new Date(student.subscriptionExpiredAt);
  if (new Date() < expiredAt) return null;
  const byDays = addDays(expiredAt, FEE_REMINDER_DAYS);
  const byMonthEnd = endOfMonth(expiredAt);
  return { expiryGraceEndsAt: (byDays > byMonthEnd ? byDays : byMonthEnd).toISOString() };
};

module.exports = {
  trialFieldsForNewStudent,
  computeAccess,
  toStudentView,
  daysLeft,
  needsRenewal,
  activateSubscriptionPatch,
  adminGracePatch,
  ensureExpiryGrace,
};
