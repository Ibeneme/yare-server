const mongoose = require("mongoose");
const { MONGO_URI, DB_MODE } = require("./env");

let memoryServer = null;

/**
 * No external database. By default the server runs an in-memory MongoDB (mongodb-memory-server):
 * every start is clean, the only account is the Super Admin (see seed.service), and nothing is
 * kept after the process stops. Set DB_MODE=mongo and MONGO_URI to use a real database again.
 */
const connectDB = async () => {
  try {
    if (DB_MODE === "mongo") {
      if (!MONGO_URI) throw new Error("DB_MODE=mongo needs MONGO_URI");
      await mongoose.connect(MONGO_URI);
      console.log("MongoDB connected");
      return;
    }
    const { MongoMemoryServer } = require("mongodb-memory-server");
    memoryServer = await MongoMemoryServer.create();
    await mongoose.connect(memoryServer.getUri("yare"));
    console.log("In-memory database ready (clean start, nothing is saved after the server stops)");
  } catch (error) {
    console.error("Database start failed:", error.message);
    process.exit(1);
  }
};

const stopDB = async () => {
  await mongoose.disconnect().catch(() => {});
  if (memoryServer) await memoryServer.stop().catch(() => {});
};

module.exports = connectDB;
module.exports.stopDB = stopDB;
