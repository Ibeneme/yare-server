// userType is what the frontend's cookies/JWT claim use. "admin" userType covers both the
// server role "admin" and "superadmin" (role is a sub-distinction carried in the record).
const USER_TYPES = Object.freeze({
  ADMIN: "admin",
  TEACHER: "teacher",
  STUDENT: "student",
  PARENT: "parent",
});

const ROLES = Object.freeze({
  SUPER_ADMIN: "superadmin",
  ADMIN: "admin",
  TEACHER: "teacher",
  STUDENT: "student",
  PARENT: "parent",
});

const STAFF_USER_TYPES = [USER_TYPES.ADMIN]; // admin + superadmin, both userType "admin"
const HOST_USER_TYPES = [USER_TYPES.TEACHER, USER_TYPES.ADMIN];

/** Which Collection a userType lives in — see state/index.js. */
const COLLECTION_FOR_USER_TYPE = {
  [USER_TYPES.ADMIN]: "admins",
  [USER_TYPES.TEACHER]: "teachers",
  [USER_TYPES.STUDENT]: "students",
  [USER_TYPES.PARENT]: "parents",
};

const CURRENCIES = Object.freeze(["NGN", "USD"]);
const REMINDER_MINUTES_BEFORE = 30;

// Section 3 — subscription lifecycle (kept as a derived view over AccessState, not a literal field set).
const FEE_REMINDER_DAYS = 14;
const GRACE_DURATIONS = Object.freeze({
  "3d": { label: "3 days", days: 3 },
  "1w": { label: "1 week", days: 7 },
  "4w": { label: "4 weeks", days: 28 },
  "3m": { label: "3 months", months: 3 },
});

const TRIAL_PRESETS = Object.freeze([7, 14, 28, 42]);
const DEFAULT_TRIAL_DAYS = 14;

const PERK_KINDS = Object.freeze(["none", "free_month", "discount", "custom"]);

const TASK_STATUSES = Object.freeze(["todo", "in_progress", "done"]);
const TASK_PRIORITIES = Object.freeze(["low", "medium", "high"]);

const ANNOUNCEMENT_KINDS = Object.freeze(["announcement", "maintenance", "banner"]);
const SEVERITIES = Object.freeze(["info", "success", "warning", "critical"]);

module.exports = {
  USER_TYPES,
  ROLES,
  STAFF_USER_TYPES,
  HOST_USER_TYPES,
  COLLECTION_FOR_USER_TYPE,
  CURRENCIES,
  REMINDER_MINUTES_BEFORE,
  FEE_REMINDER_DAYS,
  GRACE_DURATIONS,
  TRIAL_PRESETS,
  DEFAULT_TRIAL_DAYS,
  PERK_KINDS,
  TASK_STATUSES,
  TASK_PRIORITIES,
  ANNOUNCEMENT_KINDS,
  SEVERITIES,
};
