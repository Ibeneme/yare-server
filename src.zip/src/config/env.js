const dotenv = require("dotenv");
dotenv.config();

// Class times are computed in server-local time, so pin the timezone explicitly.
process.env.TZ = process.env.TZ || "Africa/Lagos";

module.exports = {
  NODE_ENV: process.env.NODE_ENV || "development",
  PORT: Number(process.env.PORT) || 5001,
  JWT_SECRET: process.env.JWT_SECRET || "dev-only-change-me",
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || "7d",
  FRONTEND_URL: process.env.FRONTEND_URL || "http://localhost:5173",
  CORS_ORIGINS: (process.env.CORS_ORIGINS || "*").split(",").map((s) => s.trim()),

  // Paystack
  PAYSTACK_SECRET_KEY: process.env.PAYSTACK_SECRET_KEY || "",
  PAYSTACK_BASE_URL: "https://api.paystack.co",

  // Email (nodemailer SMTP transport)
  SMTP_HOST: process.env.SMTP_HOST || "",
  SMTP_PORT: Number(process.env.SMTP_PORT) || 587,
  SMTP_USER: process.env.SMTP_USER || "",
  SMTP_PASS: process.env.SMTP_PASS || "",
  MAIL_FROM: process.env.MAIL_FROM || "Yare Height <no-reply@yareheight.com>",

  // The one hardcoded Super Admin, seeded fresh on every boot (no external DB — see src/state).
  SUPER_ADMIN_EMAIL: "ikennaibenemee@gmail.com",
  SUPER_ADMIN_PASSWORD: process.env.SUPER_ADMIN_PASSWORD || "Testing1234@",

  SOCKET_REQUIRE_AUTH: process.env.SOCKET_REQUIRE_AUTH !== "false",
};
