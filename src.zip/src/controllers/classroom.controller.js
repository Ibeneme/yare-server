const { db } = require("../state");
const { ROLES } = require("../config/constants");
const { HttpError, asyncHandler } = require("../utils/httpError");

// Section 6 — Role Access Matrix check, shared by the REST endpoints and the socket layer.
const canAccessClass = (user, klass) => {
  if ([ROLES.ADMIN, ROLES.SUPER_ADMIN].includes(user.role)) return true;
  if (user.role === ROLES.TEACHER) return klass.teacherId === user.id;
  if (user.role === ROLES.STUDENT) return klass.studentIds.includes(user.id);
  if (user.role === ROLES.PARENT) {
    const wardIds = db.students.find((s) => s.parentId === user.id).map((s) => s.id);
    return klass.studentIds.some((id) => wardIds.includes(id));
  }
  return false;
};

const getClassOr404 = (id) => {
  const klass = db.classes.findById(id);
  if (!klass) throw new HttpError(404, "Class not found");
  return klass;
};

// In-Class Assignments — teachers post live assignments during sessions.
const postAssignment = asyncHandler(async (req, res) => {
  const klass = getClassOr404(req.params.classId);
  if (req.user.role !== ROLES.TEACHER || klass.teacherId !== req.user.id) {
    throw new HttpError(403, "Only the class teacher can post an assignment here");
  }
  const { title, instructions, dueAt } = req.body;
  if (!title) throw new HttpError(400, "title is required");

  const assignment = db.classAssignments.insert({
    classId: klass.id,
    title,
    instructions: instructions || "",
    dueAt: dueAt || null,
    postedByUserId: req.user.id,
    submissions: [],
  });
  res.status(201).json({ ok: true, assignment });
});

const listAssignments = asyncHandler(async (req, res) => {
  const klass = getClassOr404(req.params.classId);
  if (!canAccessClass(req.user, klass)) throw new HttpError(403, "Not authorized for this class");
  res.json({ ok: true, assignments: db.classAssignments.find((a) => a.classId === klass.id) });
});

// Blocked for read-only students by studentAccess.middleware before it ever reaches here.
const submitAssignment = asyncHandler(async (req, res) => {
  const assignment = db.classAssignments.findById(req.params.assignmentId);
  if (!assignment) throw new HttpError(404, "Assignment not found");
  if (req.user.role !== ROLES.STUDENT) throw new HttpError(403, "Only a student can submit");

  const submissions = [...assignment.submissions.filter((s) => s.studentId !== req.user.id), {
    studentId: req.user.id,
    content: req.body.content || "",
    submittedAt: new Date().toISOString(),
  }];
  const updated = db.classAssignments.update(assignment.id, { submissions });
  res.json({ ok: true, assignment: updated });
});

// Join metadata the client needs before opening the socket connection (also gated by
// studentReadOnlyGuard for read-only students).
const getJoinInfo = asyncHandler(async (req, res) => {
  const klass = getClassOr404(req.params.classId);
  if (!canAccessClass(req.user, klass)) throw new HttpError(403, "Not authorized for this class");
  res.json({ ok: true, roomId: klass.id, title: klass.title });
});

module.exports = { postAssignment, listAssignments, submitAssignment, getJoinInfo, canAccessClass };
