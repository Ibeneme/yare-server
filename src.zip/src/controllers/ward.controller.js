const { db } = require("../state");
const { ROLES } = require("../config/constants");
const { hashPassword } = require("../utils/password");
const { HttpError, asyncHandler } = require("../utils/httpError");
const { findAccountByEmail, toPublic } = require("../services/account.service");
const { startTrialForStudent } = require("../services/subscription.service");

// Section 2 — Multi-Ward Registration: a parent can add and manage multiple student profiles.
const addWard = asyncHandler(async (req, res) => {
  const { firstName, lastName, email, password, gradeId, subjectIds = [], classIds = [] } = req.body;
  if (!firstName || !lastName) throw new HttpError(400, "firstName and lastName are required");
  if (email && findAccountByEmail(email)) throw new HttpError(409, "An account with this email already exists");

  const student = db.students.insert({
    firstName,
    lastName,
    email: email || null,
    parentId: req.user.id,
    gradeId: gradeId || null,
    subjectIds,
    classIds,
    passwordHash: password ? hashPassword(password) : null,
    photoUrl: null,
  });
  startTrialForStudent(student.id);
  res.status(201).json({ ok: true, ward: toPublic(student) });
});

const listMyWards = asyncHandler(async (req, res) => {
  const wards = db.students.find((s) => s.parentId === req.user.id).map(toPublic);
  res.json({ ok: true, wards });
});

// Academic & Class Enrollment Control: parent chooses grade/subjects/classes per ward.
const updateWardEnrollment = asyncHandler(async (req, res) => {
  const ward = db.students.findById(req.params.id);
  if (!ward || ward.parentId !== req.user.id) throw new HttpError(404, "Ward not found");

  const { gradeId, subjectIds, classIds } = req.body;
  const patch = {};
  if (gradeId !== undefined) patch.gradeId = gradeId;
  if (subjectIds !== undefined) patch.subjectIds = subjectIds;
  if (classIds !== undefined) patch.classIds = classIds;

  const updated = db.students.update(ward.id, patch);
  res.json({ ok: true, ward: toPublic(updated) });
});

// Shared Profile Control — both parent and student may update the student's own profile details.
const updateWardProfile = asyncHandler(async (req, res) => {
  const ward = db.students.findById(req.params.id);
  if (!ward) throw new HttpError(404, "Ward not found");
  const isOwner = req.user.role === ROLES.STUDENT && req.user.id === ward.id;
  const isParent = req.user.role === ROLES.PARENT && ward.parentId === req.user.id;
  if (!isOwner && !isParent) throw new HttpError(403, "Not authorized to edit this profile");

  const { firstName, lastName, phone, photoUrl } = req.body;
  const updated = db.students.update(ward.id, {
    ...(firstName && { firstName }),
    ...(lastName && { lastName }),
    ...(phone !== undefined && { phone }),
    ...(photoUrl !== undefined && { photoUrl }),
  });
  res.json({ ok: true, ward: toPublic(updated) });
});

module.exports = { addWard, listMyWards, updateWardEnrollment, updateWardProfile };
