const { db } = require("../state");
const { HttpError, asyncHandler } = require("../utils/httpError");

// Section 4 — Platform Announcement Banner: dismissible top-level banners.
const createAnnouncement = asyncHandler(async (req, res) => {
  const { title, body, kind = "info", startsAt, endsAt } = req.body;
  if (!title) throw new HttpError(400, "title is required");
  const announcement = db.announcements.insert({ title, body: body || "", kind, startsAt: startsAt || null, endsAt: endsAt || null, active: true });
  res.status(201).json({ ok: true, announcement });
});

const listActiveAnnouncements = asyncHandler(async (req, res) => {
  const now = new Date();
  const announcements = db.announcements.find((a) => {
    if (!a.active) return false;
    if (a.startsAt && now < new Date(a.startsAt)) return false;
    if (a.endsAt && now > new Date(a.endsAt)) return false;
    return true;
  });
  res.json({ ok: true, announcements });
});

const listAllAnnouncements = asyncHandler(async (req, res) => res.json({ ok: true, announcements: db.announcements.all() }));

const updateAnnouncement = asyncHandler(async (req, res) => {
  const announcement = db.announcements.update(req.params.id, req.body);
  if (!announcement) throw new HttpError(404, "Announcement not found");
  res.json({ ok: true, announcement });
});

const deleteAnnouncement = asyncHandler(async (req, res) => {
  db.announcements.delete(req.params.id);
  res.json({ ok: true });
});

module.exports = { createAnnouncement, listActiveAnnouncements, listAllAnnouncements, updateAnnouncement, deleteAnnouncement };
