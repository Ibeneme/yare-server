const { db } = require("../state");
const { ROLES, TASK_STATUS } = require("../config/constants");
const { HttpError, asyncHandler } = require("../utils/httpError");

// Section 6 — Teacher Task Board (own daily work) + Admin Task Tracker (platform operations).
// Both share one model; `scope` tells them apart.
const createTask = asyncHandler(async (req, res) => {
  const { title, description, dueAt, assigneeId } = req.body;
  if (!title) throw new HttpError(400, "title is required");
  const scope = req.user.role === ROLES.TEACHER ? "teacher" : "admin";

  const task = db.tasks.insert({
    title,
    description: description || "",
    dueAt: dueAt || null,
    status: TASK_STATUS.TODO,
    scope,
    ownerId: req.user.id,
    assigneeId: assigneeId || req.user.id,
  });
  res.status(201).json({ ok: true, task });
});

const listTasks = asyncHandler(async (req, res) => {
  const { role, id } = req.user;
  let tasks = db.tasks.all();
  if (role === ROLES.TEACHER) tasks = tasks.filter((t) => t.scope === "teacher" && t.ownerId === id);
  // Admin/Super Admin sees everything (the tracker), others see what's assigned to them.
  if (![ROLES.ADMIN, ROLES.SUPER_ADMIN].includes(role) && role !== ROLES.TEACHER) {
    tasks = tasks.filter((t) => t.assigneeId === id);
  }
  res.json({ ok: true, tasks });
});

const updateTask = asyncHandler(async (req, res) => {
  const task = db.tasks.findById(req.params.id);
  if (!task) throw new HttpError(404, "Task not found");
  const updated = db.tasks.update(task.id, req.body);
  res.json({ ok: true, task: updated });
});

const deleteTask = asyncHandler(async (req, res) => {
  db.tasks.delete(req.params.id);
  res.json({ ok: true });
});

module.exports = { createTask, listTasks, updateTask, deleteTask };
