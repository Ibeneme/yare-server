const { db } = require("../state");
const { ROLES } = require("../config/constants");
const { hashPassword, comparePassword } = require("../utils/password");
const { signToken } = require("../utils/jwt");
const { HttpError, asyncHandler } = require("../utils/httpError");
const { findAccountByEmail, toPublic } = require("../services/account.service");
const { startTrialForStudent } = require("../services/subscription.service");

const issueSession = (account, role) => ({
  token: signToken({ id: account.id, role }),
  user: { ...toPublic(account), role },
});

// Section 1 — Parents & Students self-register via public signup endpoints.
const signupParent = asyncHandler(async (req, res) => {
  const { firstName, lastName, email, password, phone } = req.body;
  if (!firstName || !lastName || !email || !password) throw new HttpError(400, "Missing required fields");
  if (findAccountByEmail(email)) throw new HttpError(409, "An account with this email already exists");

  const parent = db.parents.insert({
    firstName,
    lastName,
    email,
    phone: phone || null,
    passwordHash: hashPassword(password),
    photoUrl: null,
  });
  res.status(201).json({ ok: true, ...issueSession(parent, ROLES.PARENT) });
});

// Students self-register, but are normally created by a parent adding a ward (see ward.controller).
// This endpoint covers a student who signs up directly.
const signupStudent = asyncHandler(async (req, res) => {
  const { firstName, lastName, email, password } = req.body;
  if (!firstName || !lastName || !email || !password) throw new HttpError(400, "Missing required fields");
  if (findAccountByEmail(email)) throw new HttpError(409, "An account with this email already exists");

  const student = db.students.insert({
    firstName,
    lastName,
    email,
    parentId: null,
    gradeId: null,
    subjectIds: [],
    classIds: [],
    passwordHash: hashPassword(password),
    photoUrl: null,
  });
  startTrialForStudent(student.id);
  res.status(201).json({ ok: true, ...issueSession(student, ROLES.STUDENT) });
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const account = findAccountByEmail(email);
  if (!account || !comparePassword(password, account.passwordHash)) {
    throw new HttpError(401, "Invalid email or password");
  }
  const role = account.role || (db.parents.findById(account.id) ? ROLES.PARENT : ROLES.STUDENT);
  res.json({ ok: true, ...issueSession(account, role) });
});

const me = asyncHandler(async (req, res) => {
  res.json({ ok: true, user: { ...toPublic(req.user.account), role: req.user.role } });
});

// Section 1 — In-Profile Change Password.
const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword, confirmPassword } = req.body;
  if (!currentPassword || !newPassword || newPassword !== confirmPassword) {
    throw new HttpError(400, "Check your current password and that the new password matches its confirmation");
  }
  const { account, role } = req.user;
  if (!comparePassword(currentPassword, account.passwordHash)) {
    throw new HttpError(400, "Current password is incorrect");
  }
  const { collectionForRole } = require("../services/account.service");
  collectionForRole(role).update(account.id, { passwordHash: hashPassword(newPassword) });
  res.json({ ok: true, message: "Password updated" });
});

module.exports = { signupParent, signupStudent, login, me, changePassword };
