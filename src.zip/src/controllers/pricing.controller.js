const { db } = require("../state");
const { HttpError, asyncHandler } = require("../utils/httpError");

// Section 3 — Dual-Currency Admin Configuration: pricing tiers for grades, subjects, perks,
// in NGN (local) and USD (international).
const createPricing = asyncHandler(async (req, res) => {
  const { label, gradeId, subjectId, amountNgn, amountUsd } = req.body;
  if (!label || amountNgn == null || amountUsd == null) {
    throw new HttpError(400, "label, amountNgn and amountUsd are required");
  }
  const pricing = db.pricing.insert({ label, gradeId: gradeId || null, subjectId: subjectId || null, amountNgn, amountUsd });
  res.status(201).json({ ok: true, pricing });
});

const listPricing = asyncHandler(async (req, res) => res.json({ ok: true, pricing: db.pricing.all() }));

const updatePricing = asyncHandler(async (req, res) => {
  const pricing = db.pricing.update(req.params.id, req.body);
  if (!pricing) throw new HttpError(404, "Pricing tier not found");
  res.json({ ok: true, pricing });
});

const deletePricing = asyncHandler(async (req, res) => {
  db.pricing.delete(req.params.id);
  res.json({ ok: true });
});

module.exports = { createPricing, listPricing, updatePricing, deletePricing };
