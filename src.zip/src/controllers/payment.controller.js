const { db } = require("../state");
const { ROLES } = require("../config/constants");
const { HttpError, asyncHandler } = require("../utils/httpError");
const { initializeCheckout, verifyWebhookSignature } = require("../services/paystack.service");
const { activateSubscription } = require("../services/subscription.service");
const { notify } = require("../services/notification.service");
const { sendMail } = require("../services/email.service");
const { paymentReceiptEmail } = require("../templates/notices.template");
const { FRONTEND_URL } = require("../config/env");

// Section 3 — Payment Integration: secure checkout via Paystack, metadata ties it back to the
// student/ward being paid for.
const initCheckout = asyncHandler(async (req, res) => {
  const { pricingId, studentId, currency } = req.body;
  if (!pricingId || !studentId || !currency) throw new HttpError(400, "pricingId, studentId and currency are required");

  const pricing = db.pricing.findById(pricingId);
  const student = db.students.findById(studentId);
  if (!pricing || !student) throw new HttpError(404, "Pricing tier or student not found");
  if (student.parentId !== req.user.id) throw new HttpError(403, "Not your ward");

  const amountMajor = currency === "USD" ? pricing.amountUsd : pricing.amountNgn;
  const amountMinorUnits = Math.round(amountMajor * 100);

  const checkout = await initializeCheckout({
    email: req.user.account.email,
    amountMinorUnits,
    currency,
    metadata: { studentId, pricingId, parentId: req.user.id },
    callbackUrl: `${FRONTEND_URL}/app/billing/callback`,
  });

  db.transactions.insert({
    reference: checkout.reference,
    parentId: req.user.id,
    studentId,
    pricingId,
    currency,
    amount: amountMajor,
    status: "pending",
  });

  res.json({ ok: true, ...checkout });
});

// Section 3 — Signature-verified webhook. Mounted BEFORE the json body-parser's normal use so
// req.rawBody is available (see app.js) — Paystack signs the exact raw bytes.
const paystackWebhook = asyncHandler(async (req, res) => {
  const signature = req.headers["x-paystack-signature"];
  if (!verifyWebhookSignature(req.rawBody, signature)) {
    return res.status(401).json({ ok: false, message: "Invalid signature" });
  }

  const event = req.body;
  if (event.event === "charge.success") {
    const { reference } = event.data;
    const txn = db.transactions.findOne((t) => t.reference === reference);
    if (txn && txn.status !== "success") {
      db.transactions.update(txn.id, { status: "success", paidAt: new Date().toISOString() });
      activateSubscription(txn.studentId, { currency: txn.currency, planLabel: "Subscription renewal", months: 1 });

      const parent = db.parents.findById(txn.parentId);
      const student = db.students.findById(txn.studentId);
      notify({ userId: txn.parentId, role: "parent", type: "billing", title: "Payment received", message: `Payment of ${txn.currency} ${txn.amount} confirmed.` });
      if (parent) {
        await sendMail({
          to: parent.email,
          subject: "Payment received — Yare Height",
          html: paymentReceiptEmail({
            parentName: parent.firstName,
            amount: txn.amount,
            currency: txn.currency,
            reference,
            planLabel: student ? `${student.firstName}'s subscription` : "subscription",
          }),
        });
      }
    }
  }
  res.sendStatus(200);
});

// Parents view their own transaction logs.
const myTransactions = asyncHandler(async (req, res) => {
  res.json({ ok: true, transactions: db.transactions.find((t) => t.parentId === req.user.id) });
});

// Section 3 — Admins view a global platform transaction dashboard with revenue summaries.
const transactionsDashboard = asyncHandler(async (req, res) => {
  const all = db.transactions.all();
  const successful = all.filter((t) => t.status === "success");
  const revenueByCurrency = successful.reduce((acc, t) => {
    acc[t.currency] = (acc[t.currency] || 0) + t.amount;
    return acc;
  }, {});
  res.json({ ok: true, transactions: all, revenueByCurrency, count: all.length });
});

module.exports = { initCheckout, paystackWebhook, myTransactions, transactionsDashboard };
