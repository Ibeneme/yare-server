const { db } = require("../state");
const { ROLES } = require("../config/constants");
const { hashPassword } = require("../utils/password");
const { HttpError, asyncHandler } = require("../utils/httpError");
const { findAccountByEmail, toPublic } = require("../services/account.service");

// Section 1 — Account Provisioning Rules.
// Super Admins & Admins: created exclusively by the Super Admin.
const createAdmin = asyncHandler(async (req, res) => {
  if (req.user.role !== ROLES.SUPER_ADMIN) throw new HttpError(403, "Only the Super Admin can create admins");
  const { firstName, lastName, email, password, asSuperAdmin } = req.body;
  if (!firstName || !lastName || !email || !password) throw new HttpError(400, "Missing required fields");
  if (findAccountByEmail(email)) throw new HttpError(409, "An account with this email already exists");

  const admin = db.users.insert({
    role: asSuperAdmin ? ROLES.SUPER_ADMIN : ROLES.ADMIN,
    firstName,
    lastName,
    email,
    passwordHash: hashPassword(password),
    photoUrl: null,
  });
  res.status(201).json({ ok: true, user: toPublic(admin) });
});

// Teachers: provisioned by Admin or Super Admin.
const createTeacher = asyncHandler(async (req, res) => {
  if (![ROLES.ADMIN, ROLES.SUPER_ADMIN].includes(req.user.role)) {
    throw new HttpError(403, "Only an Admin or Super Admin can provision teachers");
  }
  const { firstName, lastName, email, password, subjectIds = [] } = req.body;
  if (!firstName || !lastName || !email || !password) throw new HttpError(400, "Missing required fields");
  if (findAccountByEmail(email)) throw new HttpError(409, "An account with this email already exists");

  const teacher = db.users.insert({
    role: ROLES.TEACHER,
    firstName,
    lastName,
    email,
    subjectIds,
    passwordHash: hashPassword(password),
    photoUrl: null,
  });
  res.status(201).json({ ok: true, user: toPublic(teacher) });
});

// Section 1 — Super Admin Transfer: only the active Super Admin can transfer the role,
// and only to an existing Teacher.
const transferSuperAdmin = asyncHandler(async (req, res) => {
  if (req.user.role !== ROLES.SUPER_ADMIN) throw new HttpError(403, "Only the Super Admin can transfer the role");
  const { teacherId } = req.body;
  const teacher = db.users.findById(teacherId);
  if (!teacher || teacher.role !== ROLES.TEACHER) throw new HttpError(400, "Target must be an existing Teacher");

  db.users.update(teacher.id, { role: ROLES.SUPER_ADMIN });
  db.users.update(req.user.id, { role: ROLES.ADMIN });
  res.json({ ok: true, message: `Super Admin transferred to ${teacher.firstName} ${teacher.lastName}` });
});

const listStaff = asyncHandler(async (req, res) => {
  const { role } = req.query;
  const staff = db.users.find((u) => !role || u.role === role).map(toPublic);
  res.json({ ok: true, staff });
});

module.exports = { createAdmin, createTeacher, transferSuperAdmin, listStaff };
