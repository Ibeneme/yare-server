const { asyncHandler } = require("../utils/httpError");
const notificationService = require("../services/notification.service");

const listMyNotifications = asyncHandler(async (req, res) => {
  res.json({ ok: true, notifications: notificationService.listForUser(req.user.id) });
});

const markNotificationRead = asyncHandler(async (req, res) => {
  const n = notificationService.markRead(req.params.id, req.user.id);
  res.json({ ok: true, notification: n });
});

// Section 2 — Parent Alert & Class-Join Preferences.
const getMyPrefs = asyncHandler(async (req, res) => {
  res.json({ ok: true, prefs: notificationService.getPrefsForParent(req.user.id) });
});

const updateMyPrefs = asyncHandler(async (req, res) => {
  res.json({ ok: true, prefs: notificationService.updatePrefsForParent(req.user.id, req.body) });
});

module.exports = { listMyNotifications, markNotificationRead, getMyPrefs, updateMyPrefs };
