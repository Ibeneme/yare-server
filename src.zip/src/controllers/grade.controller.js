const { db } = require("../state");
const { HttpError, asyncHandler } = require("../utils/httpError");

const listGrades = asyncHandler(async (req, res) => res.json({ ok: true, grades: db.grades.all() }));

const createGrade = asyncHandler(async (req, res) => {
  const { name, description } = req.body;
  if (!name) throw new HttpError(400, "name is required");
  res.status(201).json({ ok: true, grade: db.grades.insert({ name, description: description || "" }) });
});

const updateGrade = asyncHandler(async (req, res) => {
  const grade = db.grades.update(req.params.id, req.body);
  if (!grade) throw new HttpError(404, "Grade not found");
  res.json({ ok: true, grade });
});

const deleteGrade = asyncHandler(async (req, res) => {
  db.grades.delete(req.params.id);
  res.json({ ok: true });
});

const listSubjects = asyncHandler(async (req, res) => {
  const { gradeId } = req.query;
  res.json({ ok: true, subjects: db.subjects.find((s) => !gradeId || s.gradeId === gradeId) });
});

const createSubject = asyncHandler(async (req, res) => {
  const { name, gradeId } = req.body;
  if (!name) throw new HttpError(400, "name is required");
  res.status(201).json({ ok: true, subject: db.subjects.insert({ name, gradeId: gradeId || null }) });
});

const updateSubject = asyncHandler(async (req, res) => {
  const subject = db.subjects.update(req.params.id, req.body);
  if (!subject) throw new HttpError(404, "Subject not found");
  res.json({ ok: true, subject });
});

const deleteSubject = asyncHandler(async (req, res) => {
  db.subjects.delete(req.params.id);
  res.json({ ok: true });
});

module.exports = {
  listGrades,
  createGrade,
  updateGrade,
  deleteGrade,
  listSubjects,
  createSubject,
  updateSubject,
  deleteSubject,
};
