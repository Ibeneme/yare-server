const { db } = require("../state");
const { GRACE_OPTIONS, TRIAL_OPTIONS } = require("../config/constants");
const { HttpError, asyncHandler } = require("../utils/httpError");
const { getSettings, updateSettings } = require("../services/settings.service");
const { applyAdminGrace } = require("../services/subscription.service");

const readSettings = asyncHandler(async (req, res) => res.json({ ok: true, settings: getSettings() }));

// Section 4 — Configurable Free Trial: toggle on/off, set duration (preset or custom days).
const updateTrialSettings = asyncHandler(async (req, res) => {
  const { trialEnabled, trialDays, trialPreset } = req.body;
  const patch = {};
  if (trialEnabled !== undefined) patch.trialEnabled = trialEnabled;
  if (trialPreset && TRIAL_OPTIONS[trialPreset]) patch.trialDays = TRIAL_OPTIONS[trialPreset];
  else if (trialDays !== undefined) patch.trialDays = Number(trialDays);
  res.json({ ok: true, settings: updateSettings(patch) });
});

const updateMaintenance = asyncHandler(async (req, res) => {
  const { maintenanceMode, maintenanceMessage } = req.body;
  res.json({ ok: true, settings: updateSettings({ maintenanceMode: !!maintenanceMode, maintenanceMessage: maintenanceMessage || "" }) });
});

// Section 3 — Admin Grace Override Toggle: 3 days / 1 week / 4 weeks / 3 months.
const grantGrace = asyncHandler(async (req, res) => {
  const { studentId, preset } = req.body;
  if (!studentId || !GRACE_OPTIONS[preset]) throw new HttpError(400, `preset must be one of ${Object.keys(GRACE_OPTIONS).join(", ")}`);
  const sub = applyAdminGrace(studentId, preset);
  res.json({ ok: true, subscription: sub });
});

module.exports = { readSettings, updateTrialSettings, updateMaintenance, grantGrace };
