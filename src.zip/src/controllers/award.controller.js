const { db } = require("../state");
const { HttpError, asyncHandler } = require("../utils/httpError");
const awardService = require("../services/award.service");

// Section 5 — Admin Award Creation & Issuance.
const createAwardTemplate = asyncHandler(async (req, res) => {
  const { title, description, perkType, perkValue } = req.body;
  if (!title || !perkType) throw new HttpError(400, "title and perkType are required");
  res.status(201).json({ ok: true, template: awardService.createTemplate({ title, description, perkType, perkValue }) });
});

const listAwardTemplates = asyncHandler(async (req, res) => res.json({ ok: true, templates: awardService.listTemplates() }));

const issueAward = asyncHandler(async (req, res) => {
  const { templateId, studentId } = req.body;
  const student = db.students.findById(studentId);
  if (!student) throw new HttpError(404, "Student not found");
  const parent = student.parentId ? db.parents.findById(student.parentId) : null;

  const grant = await awardService.issueAward({ templateId, studentId, parent, student, issuedByUserId: req.user.id });
  res.status(201).json({ ok: true, grant });
});

// Section 5 — Student & Parent Visibility.
const listMyAwards = asyncHandler(async (req, res) => {
  const { ROLES } = require("../config/constants");
  let studentId = req.params.studentId;
  if (req.user.role === ROLES.STUDENT) studentId = req.user.id;
  if (req.user.role === ROLES.PARENT) {
    const ward = db.students.findById(studentId);
    if (!ward || ward.parentId !== req.user.id) throw new HttpError(403, "Not your ward");
  }
  res.json({ ok: true, grants: awardService.listGrantsForStudent(studentId) });
});

module.exports = { createAwardTemplate, listAwardTemplates, issueAward, listMyAwards };
