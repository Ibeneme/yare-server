const { db } = require("../state");
const { ROLES } = require("../config/constants");
const { HttpError, asyncHandler } = require("../utils/httpError");

// Section 2 — Flexible Class Scheduling. A class belongs to a grade, can target either
// individual students or a group, and carries a recurring schedule.
const createClass = asyncHandler(async (req, res) => {
  const { title, gradeId, subjectId, teacherId, studentIds = [], groupId, schedule } = req.body;
  if (!title || !gradeId || !teacherId || !schedule) {
    throw new HttpError(400, "title, gradeId, teacherId and schedule are required");
  }
  const klass = db.classes.insert({
    title,
    gradeId,
    subjectId: subjectId || null,
    teacherId,
    studentIds,
    groupId: groupId || null,
    schedule, // { days: ["mon","wed"], startTime: "15:30", durationMinutes: 45, startDate, endDate? }
    status: "scheduled",
  });
  res.status(201).json({ ok: true, class: klass });
});

const updateClass = asyncHandler(async (req, res) => {
  const klass = db.classes.update(req.params.id, req.body);
  if (!klass) throw new HttpError(404, "Class not found");
  res.json({ ok: true, class: klass });
});

const deleteClass = asyncHandler(async (req, res) => {
  db.classes.delete(req.params.id);
  res.json({ ok: true });
});

// Section 2/6 — Role Access Matrix: Teachers see assigned classes, Admins see all,
// Parents see their children's classes.
const listClasses = asyncHandler(async (req, res) => {
  const { role, id, account } = req.user;
  let classes = db.classes.all();

  if (role === ROLES.TEACHER) classes = classes.filter((c) => c.teacherId === id);
  if (role === ROLES.PARENT) {
    const wardIds = db.students.find((s) => s.parentId === id).map((s) => s.id);
    classes = classes.filter((c) => c.studentIds.some((sid) => wardIds.includes(sid)));
  }
  if (role === ROLES.STUDENT) {
    classes = classes.filter(
      (c) => c.studentIds.includes(id) || (account.groupId && c.groupId === account.groupId),
    );
  }
  res.json({ ok: true, classes });
});

const createGroup = asyncHandler(async (req, res) => {
  const { name, studentIds = [] } = req.body;
  if (!name) throw new HttpError(400, "name is required");
  res.status(201).json({ ok: true, group: db.groups.insert({ name, studentIds }) });
});

const listGroups = asyncHandler(async (req, res) => res.json({ ok: true, groups: db.groups.all() }));

module.exports = { createClass, updateClass, deleteClass, listClasses, createGroup, listGroups };
