const { db } = require("../state");
const { ROLES, SUBSCRIPTION_STATUS } = require("../config/constants");
const { HttpError, asyncHandler } = require("../utils/httpError");
const { getSubscriptionForStudent, reconcileStatus, daysRemainingInGrace } = require("../services/subscription.service");

// Section 3 — "Crucial Rule": never surface fee/billing wording to the student. We enforce
// that right here, at the one place the student's own app reads subscription state from.
const neutralizeForStudent = (sub) => ({
  status: sub.status === SUBSCRIPTION_STATUS.READ_ONLY ? "read_only" : "active",
});

const getMySubscription = asyncHandler(async (req, res) => {
  const studentId = req.user.role === ROLES.STUDENT ? req.user.id : req.query.studentId;
  if (!studentId) throw new HttpError(400, "studentId is required");

  if (req.user.role === ROLES.PARENT) {
    const ward = db.students.findById(studentId);
    if (!ward || ward.parentId !== req.user.id) throw new HttpError(403, "Not your ward");
  }

  let sub = getSubscriptionForStudent(studentId);
  if (!sub) throw new HttpError(404, "No subscription record yet");
  sub = reconcileStatus(sub);

  if (req.user.role === ROLES.STUDENT) return res.json({ ok: true, subscription: neutralizeForStudent(sub) });

  res.json({ ok: true, subscription: { ...sub, daysRemainingInGrace: daysRemainingInGrace(sub) } });
});

module.exports = { getMySubscription };
