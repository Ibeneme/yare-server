const { randomUUID } = require("crypto");

/**
 * A tiny in-memory collection — the whole point of Section 0's "Database Removal" rule.
 * No external database, no driver, no ORM: just structured JS state, live for the life of
 * the process and rebuilt clean on every boot (see state/index.js + services/seed.service.js).
 *
 * Records are keyed by `_id` (not `id`) so every object handed to the frontend already matches
 * its Mongoose-style contract (store/models.ts) with zero per-response renaming.
 */
class Collection {
  constructor(name) {
    this.name = name;
    this.rows = new Map(); // _id -> record
  }

  insert(data) {
    const _id = data._id || randomUUID();
    const now = new Date().toISOString();
    const record = { ...data, _id, createdAt: data.createdAt || now, updatedAt: now };
    this.rows.set(_id, record);
    return record;
  }

  findById(id) {
    return this.rows.get(id) || null;
  }

  find(predicate = () => true) {
    return [...this.rows.values()].filter(predicate);
  }

  findOne(predicate) {
    return this.find(predicate)[0] || null;
  }

  all() {
    return [...this.rows.values()];
  }

  update(id, patch) {
    const existing = this.rows.get(id);
    if (!existing) return null;
    const updated = { ...existing, ...patch, _id: id, updatedAt: new Date().toISOString() };
    this.rows.set(id, updated);
    return updated;
  }

  delete(id) {
    return this.rows.delete(id);
  }

  clear() {
    this.rows.clear();
  }

  count(predicate = () => true) {
    return this.find(predicate).length;
  }
}

module.exports = Collection;
