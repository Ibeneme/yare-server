const Collection = require("./Collection");

/**
 * The entire "database". Every domain collection lives here, in memory only.
 * Nothing persists across a restart except the single seeded Super Admin (Section 1).
 * Shapes follow the frontend's store/models.ts one-to-one wherever a field is used there.
 */
const db = {
  // People
  admins: new Collection("admins"), // superadmin + admin
  teachers: new Collection("teachers"),
  parents: new Collection("parents"),
  students: new Collection("students"),

  // Pending email-OTP signups (parent self-registration flow)
  pendingRegistrations: new Collection("pendingRegistrations"),

  // Academic structure
  grades: new Collection("grades"),
  subjects: new Collection("subjects"),
  groups: new Collection("groups"),

  // Classes & classroom
  classes: new Collection("classes"), // ClassSession
  classAssignments: new Collection("classAssignments"),
  classroomNotes: new Collection("classroomNotes"),

  // Money
  pricing: new Collection("pricing"),
  transactions: new Collection("transactions"),
  lessonFees: new Collection("lessonFees"), // per-student line items of a transaction (checkout.slice.ts)

  // Platform
  announcements: new Collection("announcements"),
  awardGrants: new Collection("awardGrants"),
  tasks: new Collection("tasks"),
  notifications: new Collection("notifications"),
  notificationPrefs: new Collection("notificationPrefs"),
  platformSettings: new Collection("platformSettings"), // singleton row
};

const resetAll = () => Object.values(db).forEach((c) => c.clear());

module.exports = { db, resetAll };
