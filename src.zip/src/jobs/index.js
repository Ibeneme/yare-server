const { startClassReminderJob } = require("./classReminder.job");
const { startSubscriptionExpiryJob } = require("./subscriptionExpiry.job");

const startJobs = () => {
  const jobs = [startClassReminderJob(), startSubscriptionExpiryJob()];
  console.log(`Background jobs running: ${jobs.length}`);
  return jobs;
};

module.exports = { startJobs };
