const cron = require("node-cron");
const { db } = require("../state");
const { REMINDER_MINUTES_BEFORE } = require("../config/constants");
const { sendMail } = require("../services/email.service");
const { notify } = require("../services/notification.service");
const { classReminderEmail } = require("../templates/notices.template");

// Section 4 (v3) / Section 7 (v6) — Automated Notification Cron Job: fires an email exactly
// 30 minutes before each scheduled class start. Runs every minute and checks each class's
// date/time against "now + 30min", using a per-class dedupe key so it never double-sends.
const sentReminders = new Set();

const occurrenceOf = (klass) => {
  if (!klass.date || !klass.time) return null;
  const dt = new Date(`${klass.date}T${klass.time}`);
  return Number.isNaN(dt.getTime()) ? null : dt;
};

const tick = async () => {
  const now = new Date();
  for (const klass of db.classes.all()) {
    const occurrence = occurrenceOf(klass);
    if (!occurrence || occurrence <= now) continue;

    const minutesAway = Math.round((occurrence - now) / 60000);
    if (minutesAway !== REMINDER_MINUTES_BEFORE) continue;

    const dedupeKey = `${klass._id}:${occurrence.toISOString()}`;
    if (sentReminders.has(dedupeKey)) continue;
    sentReminders.add(dedupeKey);

    for (const studentId of klass.studentIds || []) {
      const student = db.students.findById(studentId);
      if (!student) continue;
      notify({ userId: studentId, userType: "student", type: "class_reminder", title: "Class starting soon", message: `${klass.title} starts in 30 minutes.` });
      if (student.email) {
        await sendMail({
          to: student.email,
          subject: `${klass.title} starts in 30 minutes`,
          html: classReminderEmail({ studentName: student.firstName, className: klass.title, startTime: klass.time }),
        });
      }
      if (student.parentId) {
        notify({ userId: student.parentId, userType: "parent", type: "class_reminder", title: "Class starting soon", message: `${student.firstName}'s class ${klass.title} starts in 30 minutes.` });
      }
    }
  }
};

const startClassReminderJob = () => cron.schedule("* * * * *", tick);

module.exports = { startClassReminderJob, tick, occurrenceOf };
