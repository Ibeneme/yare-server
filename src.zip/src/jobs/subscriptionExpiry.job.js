const cron = require("node-cron");
const { db } = require("../state");
const { computeAccess, daysLeft, ensureExpiryGrace } = require("../services/access.service");
const { notify } = require("../services/notification.service");
const { sendMail } = require("../services/email.service");
const { expiryNoticeEmail } = require("../templates/notices.template");

// Section 3 — 14-Day Expiry Grace & Daily Alerts, sent to the PARENT ONLY (never the student —
// see the "Crucial Rule" in Section 3's Silent Child Read-Only Mode).
const tick = async () => {
  for (const student of db.students.all()) {
    const patch = ensureExpiryGrace(student);
    const current = patch ? db.students.update(student._id, patch) : student;
    const access = computeAccess(current);
    if (access.reason !== "expiry_grace") continue;
    if (!current.parentId) continue;
    const parent = db.parents.findById(current.parentId);
    if (!parent) continue;

    const remaining = daysLeft(access);
    notify({
      userId: parent._id,
      userType: "parent",
      type: "billing",
      title: "Subscription renewal needed",
      message: `${current.firstName}'s subscription has lapsed. ${remaining} day(s) left before view-only mode.`,
    });
    await sendMail({
      to: parent.email,
      subject: `Action needed: ${current.firstName}'s Yare Height subscription`,
      html: expiryNoticeEmail({
        parentName: parent.firstName,
        studentName: current.firstName,
        daysRemaining: remaining,
        deadlineDate: access.until ? new Date(access.until).toDateString() : "",
      }),
    });
  }
};

const startSubscriptionExpiryJob = () => cron.schedule("0 8 * * *", tick); // once a day, 08:00 server time

module.exports = { startSubscriptionExpiryJob, tick };
