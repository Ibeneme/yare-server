// Section 7 (v3 §4 echoes this) — Restyled Responsive HTML Email Templates.
// Shared shell for every transactional email: Yare Height brand palette, mobile-responsive,
// zero italics anywhere (global typography rule carries into email markup too).
const BRAND = {
  cream: "#FBF6EC",
  armyGreen: "#2F3B29",
  armyGreenDark: "#202A1C",
  sunshineYellow: "#F4C430",
  text: "#20241B",
};

const emailShell = ({ title, preheader = "", bodyHtml, ctaLabel, ctaUrl }) => `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>${title}</title>
</head>
<body style="margin:0;padding:0;background:${BRAND.cream};font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;font-style:normal;">
  <span style="display:none;max-height:0;overflow:hidden;">${preheader}</span>
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${BRAND.cream};padding:24px 0;">
    <tr><td align="center">
      <table role="presentation" width="100%" style="max-width:520px;background:#ffffff;border-radius:16px;overflow:hidden;" cellpadding="0" cellspacing="0">
        <tr>
          <td style="background:${BRAND.armyGreen};padding:20px 28px;">
            <span style="color:${BRAND.sunshineYellow};font-weight:700;font-size:18px;font-style:normal;">Yare Height</span>
          </td>
        </tr>
        <tr>
          <td style="padding:28px;color:${BRAND.text};font-size:15px;line-height:1.6;font-style:normal;">
            ${bodyHtml}
            ${
              ctaUrl
                ? `<div style="margin-top:24px;">
                     <a href="${ctaUrl}" style="display:inline-block;background:${BRAND.sunshineYellow};color:${BRAND.armyGreenDark};font-weight:700;text-decoration:none;padding:12px 22px;border-radius:999px;font-style:normal;">${ctaLabel || "Open Yare Height"}</a>
                   </div>`
                : ""
            }
          </td>
        </tr>
        <tr>
          <td style="background:${BRAND.cream};padding:16px 28px;color:#6b7360;font-size:12px;font-style:normal;">
            You're receiving this because you have an account on Yare Height.
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;

module.exports = { emailShell, BRAND };
