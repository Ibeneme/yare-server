const { emailShell } = require("./layout.template");
const { FRONTEND_URL } = require("../config/env");

// 30-minute class reminder.
const classReminderEmail = ({ studentName, className, startTime }) =>
  emailShell({
    title: "Your class starts in 30 minutes",
    preheader: `${className} starts soon`,
    bodyHtml: `
      <p>Hi there,</p>
      <p><strong>${studentName}</strong>'s class <strong>${className}</strong> starts in 30 minutes, at <strong>${startTime}</strong>.</p>
      <p>Join a few minutes early to test audio and video.</p>`,
    ctaLabel: "Join the class",
    ctaUrl: `${FRONTEND_URL}/app/classroom`,
  });

// Daily subscription expiry notice, sent only to the parent — Section 3's "Silent Child
// Read-Only Mode" rule means the student never sees wording like this.
const expiryNoticeEmail = ({ parentName, studentName, daysRemaining, deadlineDate }) =>
  emailShell({
    title: "Subscription renewal needed",
    preheader: `${studentName}'s subscription needs renewing`,
    bodyHtml: `
      <p>Hi ${parentName},</p>
      <p><strong>${studentName}</strong>'s subscription has lapsed. Learning access continues for now, but
      please renew within <strong>${daysRemaining} day(s)</strong> (by ${deadlineDate}) to keep live classes
      and new submissions available.</p>`,
    ctaLabel: "Renew now",
    ctaUrl: `${FRONTEND_URL}/app/billing`,
  });

const paymentReceiptEmail = ({ parentName, amount, currency, reference, planLabel }) =>
  emailShell({
    title: "Payment received",
    preheader: `Receipt for ${planLabel}`,
    bodyHtml: `
      <p>Hi ${parentName},</p>
      <p>Thanks — we've received your payment of <strong>${currency} ${amount}</strong> for
      <strong>${planLabel}</strong>.</p>
      <p>Reference: <strong>${reference}</strong></p>`,
    ctaLabel: "View receipt",
    ctaUrl: `${FRONTEND_URL}/app/billing/transactions`,
  });

const freeTrialStartedEmail = ({ parentName, studentName, trialDays, endsOn }) =>
  emailShell({
    title: "Free trial started",
    preheader: `${studentName}'s free trial has begun`,
    bodyHtml: `
      <p>Hi ${parentName},</p>
      <p><strong>${studentName}</strong>'s ${trialDays}-day free trial is now active and ends on
      <strong>${endsOn}</strong>.</p>`,
    ctaLabel: "Explore Yare Height",
    ctaUrl: `${FRONTEND_URL}/app`,
  });

const awardNotificationEmail = ({ parentName, studentName, awardTitle, perkLabel }) =>
  emailShell({
    title: "An award was earned!",
    preheader: `${studentName} earned ${awardTitle}`,
    bodyHtml: `
      <p>Hi ${parentName},</p>
      <p><strong>${studentName}</strong> just earned <strong>${awardTitle}</strong>${perkLabel ? ` — ${perkLabel}` : ""}.</p>`,
    ctaLabel: "See the award",
    ctaUrl: `${FRONTEND_URL}/app/awards`,
  });

module.exports = {
  classReminderEmail,
  expiryNoticeEmail,
  paymentReceiptEmail,
  freeTrialStartedEmail,
  awardNotificationEmail,
};
