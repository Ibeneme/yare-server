const mongoose = require("mongoose");

// One row per priced item, with a price in each supported currency.
const pricingSchema = new mongoose.Schema(
  {
    kind: { type: String, enum: ["grade", "subject", "perk"], required: true, index: true },
    // Grade or Subject id; unused for perks.
    refId: { type: mongoose.Schema.Types.ObjectId, index: true },
    name: { type: String, required: true, trim: true },
    description: { type: String, trim: true },
    prices: {
      NGN: { type: Number, min: 0, required: true },
      USD: { type: Number, min: 0, required: true },
    },
    // Billing period in days (matches LessonFee.duration).
    durationDays: { type: Number, default: 30, min: 1 },
    isActive: { type: Boolean, default: true },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
  },
  { timestamps: true }
);

pricingSchema.index({ kind: 1, refId: 1 }, { unique: true, partialFilterExpression: { refId: { $exists: true } } });

module.exports = mongoose.model("Pricing", pricingSchema);
