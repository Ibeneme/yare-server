const { db } = require("../state");
const { ROLES, USER_TYPES } = require("../config/constants");
const { getRoom, removeFromAllRooms } = require("./roomState");
const { computeAccess } = require("../services/access.service");

// Section 6 — Google Meet-style virtual classroom over Socket.io + WebRTC signaling.
//
// This speaks the EXACT event protocol the existing client (LiveClassPage.tsx) already uses —
// "join", "existing-users", "new-user-joined", "session-description", "ice-candidate",
// "user-left", "chat-message", "media-toggle", "start-screen-share"/"stop-screen-share",
// "raise-hand"/"lower-hand", "mute-all"/"unmute-all" → "force-mute"/"force-unmute",
// "remove-all-users" → "room-ended", "leave-room", "join-denied", "prepare-late-joiner-screen" —
// so the client needs no changes. The server only relays signaling; audio/video travel
// peer-to-peer over WebRTC once two clients have exchanged offer/answer/ICE through here.
const HOST_ROLES = [ROLES.TEACHER, ROLES.ADMIN, ROLES.SUPER_ADMIN];

const canAccessClass = (user, klass) => {
  if (user.userType === USER_TYPES.ADMIN) return true;
  if (user.userType === USER_TYPES.TEACHER) return klass.teacherId === user._id;
  if (user.userType === USER_TYPES.STUDENT) return (klass.studentIds || []).includes(user._id);
  return false;
};

const registerClassroomHandlers = (io, socket) => {
  const user = socket.user; // { _id, userType, role, name } — set by the auth gate in sockets/index.js

  socket.on("join", (classId, username, _requestedId, ack) => {
    const klass = db.classes.findById(classId);
    if (!klass) return socket.emit("join-denied", { reason: "This class couldn't be found." });
    if (!canAccessClass(user, klass)) {
      return socket.emit("join-denied", { reason: "You can't join this session right now." });
    }
    // Section 3 — Silent Child Read-Only Mode: a lapsed, un-renewed subscription blocks a
    // student from joining live sessions, but the wording stays neutral (no fee/billing mention).
    if (user.userType === USER_TYPES.STUDENT) {
      const student = db.students.findById(user._id);
      if (student && computeAccess(student).mode === "read_only") {
        return socket.emit("join-denied", { reason: "This is view-only right now. Live sessions aren't available at the moment." });
      }
    }

    const room = getRoom(classId);
    const existingUsers = [...room.participants.entries()].map(([id, p]) => ({ id, username: p.username }));

    room.participants.set(socket.id, { userId: user._id, role: user.role, username: username || user.name });
    socket.join(classId);
    socket.data.classId = classId;

    // Tell the new joiner who's already here, and who (if anyone) is currently screen-sharing —
    // the late-joiner state sync.
    socket.emit("existing-users", existingUsers, room.screenShare || null);

    // Tell everyone already here about the new joiner, so each side creates its own peer connection.
    socket.to(classId).emit("new-user-joined", { id: socket.id, username: username || user.name });

    // If someone is sharing their screen, ask that specific socket to push the screen track to
    // this late joiner once their peer connection exists.
    if (room.screenShare && room.screenShare !== socket.id) {
      io.to(room.screenShare).emit("prepare-late-joiner-screen", socket.id);
    }

    ack?.({ ok: true });
  });

  // WebRTC offer/answer relay — addressed to one peer by their socket id.
  socket.on("session-description", (sdp, targetSocketId) => {
    io.to(targetSocketId).emit("session-description", socket.id, sdp);
  });

  // WebRTC ICE candidate relay.
  socket.on("ice-candidate", (candidate, targetSocketId) => {
    io.to(targetSocketId).emit("ice-candidate", socket.id, candidate);
  });

  // Mic/camera on-off state, broadcast to the room so everyone's tile reflects it.
  socket.on("media-toggle", (mediaStatus) => {
    const classId = socket.data.classId;
    if (!classId) return;
    socket.to(classId).emit("media-toggle", { senderId: socket.id, mediaStatus });
  });

  // Screen sharing with late-joiner sync (the sync itself happens on "join", above).
  socket.on("start-screen-share", () => {
    const classId = socket.data.classId;
    if (!classId) return;
    getRoom(classId).screenShare = socket.id;
    socket.to(classId).emit("start-screen-share", socket.id);
  });

  socket.on("stop-screen-share", () => {
    const classId = socket.data.classId;
    if (!classId) return;
    const room = getRoom(classId);
    if (room.screenShare === socket.id) room.screenShare = null;
    socket.to(classId).emit("stop-screen-share");
  });

  // Live reactions.
  socket.on("raise-hand", () => {
    const classId = socket.data.classId;
    if (classId) socket.to(classId).emit("raise-hand", socket.id);
  });
  socket.on("lower-hand", () => {
    const classId = socket.data.classId;
    if (classId) socket.to(classId).emit("lower-hand", socket.id);
  });

  // Host controls — teacher/admin only.
  socket.on("mute-all", () => {
    const classId = socket.data.classId;
    if (classId && HOST_ROLES.includes(user.role)) socket.to(classId).emit("force-mute");
  });
  socket.on("unmute-all", () => {
    const classId = socket.data.classId;
    if (classId && HOST_ROLES.includes(user.role)) socket.to(classId).emit("force-unmute");
  });
  socket.on("remove-all-users", () => {
    const classId = socket.data.classId;
    if (!classId || !HOST_ROLES.includes(user.role)) return;
    io.to(classId).emit("room-ended");
    const room = getRoom(classId);
    room.participants.clear();
    room.screenShare = null;
  });

  // In-call chat — the client already appends its own outgoing message locally, so relay to
  // everyone else only.
  socket.on("chat-message", (msg) => {
    const classId = socket.data.classId;
    if (classId && msg) socket.to(classId).emit("chat-message", msg);
  });

  socket.on("leave-room", () => leaveCurrentRoom(io, socket));
  socket.on("disconnect", () => leaveCurrentRoom(io, socket));
};

const leaveCurrentRoom = (io, socket) => {
  const classId = socket.data.classId;
  if (!classId) return;
  const room = getRoom(classId);
  const wasSharing = room.screenShare === socket.id;
  removeFromAllRooms(socket.id);
  socket.leave(classId);
  socket.to(classId).emit("user-left", socket.id);
  if (wasSharing) socket.to(classId).emit("stop-screen-share");
  socket.data.classId = null;
};

module.exports = { registerClassroomHandlers };
