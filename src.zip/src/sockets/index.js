const { Server } = require("socket.io");
const { verifyToken } = require("../utils/jwt");
const { findAccountById, roleFor } = require("../services/account.service");
const { CORS_ORIGINS, SOCKET_REQUIRE_AUTH } = require("../config/env");
const { registerClassroomHandlers } = require("./classroom.socket");

const initSockets = (server) => {
  const io = new Server(server, { cors: { origin: CORS_ORIGINS, credentials: true } });

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) {
      if (SOCKET_REQUIRE_AUTH) return next(new Error("Not authenticated"));
      socket.user = { _id: "anonymous", userType: "guest", role: "guest", name: "Guest" };
      return next();
    }
    try {
      const payload = verifyToken(token);
      if (payload.purpose && payload.purpose !== "session") return next(new Error("Not authenticated"));
      const account = findAccountById(payload.id, payload.userType);
      if (!account) return next(new Error("Account no longer exists"));
      socket.user = {
        _id: account._id,
        userType: payload.userType,
        role: roleFor(account, payload.userType),
        name: `${account.firstName} ${account.lastName}`,
      };
      next();
    } catch (_err) {
      next(new Error("Invalid or expired token"));
    }
  });

  io.on("connection", (socket) => {
    registerClassroomHandlers(io, socket);
  });

  return io;
};

module.exports = { initSockets };
