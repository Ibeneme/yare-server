/**
 * Per-classroom live state, kept only for the life of the process (Section 0 — no external DB).
 * rooms[classId] = { participants: Map<socketId, {userId, role, username}>, screenShare: socketId|null }
 */
const rooms = {};

const getRoom = (classId) => {
  if (!rooms[classId]) {
    rooms[classId] = { participants: new Map(), screenShare: null };
  }
  return rooms[classId];
};

const removeFromAllRooms = (socketId) => {
  const left = [];
  Object.entries(rooms).forEach(([classId, room]) => {
    if (room.participants.delete(socketId)) {
      left.push({ classId, wasSharing: room.screenShare === socketId });
      if (room.screenShare === socketId) room.screenShare = null;
    }
  });
  return left;
};

module.exports = { rooms, getRoom, removeFromAllRooms };
