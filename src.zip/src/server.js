const http = require("http");
const env = require("./config/env"); // loads .env and pins TZ first
const { createApp } = require("./app");
const { initSockets } = require("./sockets");
const { startJobs } = require("./jobs");
const { seedSuperAdmin } = require("./services/seed.service");

const start = async () => {
  // Section 0 — no external database to connect to: state/index.js is already live in memory.
  await seedSuperAdmin();

  const app = createApp();
  const server = http.createServer(app);
  app.set("io", initSockets(server));
  startJobs();

  server.listen(env.PORT, () => console.log(`Yare Height server listening on :${env.PORT}`));

  const shutdown = () => server.close(() => process.exit(0));
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
};

start().catch((err) => {
  console.error("Failed to start:", err);
  process.exit(1);
});
