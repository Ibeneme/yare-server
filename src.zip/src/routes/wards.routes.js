const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, USER_TYPES } = require("../config/constants");
const { HttpError, asyncHandler, ok, okMessage } = require("../utils/httpError");
const { toPublic, findAccountByEmail } = require("../services/account.service");
const identity = require("../services/identity.service");

router.use(requireAuth, requireRole(ROLES.PARENT));

// GET /api/wards
router.get(
  "/",
  asyncHandler(async (req, res) => ok(res, 200, db.students.find((s) => s.parentId === req.user._id).map(toPublic))),
);

// GET /api/wards/catalogue — grades + subjects a parent can pick from.
router.get(
  "/catalogue",
  asyncHandler(async (req, res) => {
    const grades = db.grades.all().map((g) => ({ _id: g._id, title: g.title, description: g.description }));
    const subjects = db.subjects.all().map((s) => ({ _id: s._id, name: s.name, code: s.code, gradeLevel: s.gradeLevel }));
    return ok(res, 200, { grades, subjects });
  }),
);

// POST /api/wards
router.post(
  "/",
  asyncHandler(async (req, res) => {
    const { firstName, lastName, email, gradeId, subjectIds } = req.body;
    if (!firstName || !lastName) throw new HttpError(400, "firstName and lastName are required");
    if (email && findAccountByEmail(email)) throw new HttpError(409, "An account with this email already exists");

    const student = identity.createAccount(USER_TYPES.STUDENT, {
      firstName,
      lastName,
      email: email || null,
      parentId: req.user._id,
      gradeId: gradeId || null,
      subjects: subjectIds || [],
    });
    return ok(res, 201, toPublic(student));
  }),
);

// PUT /api/wards/:id
router.put(
  "/:id",
  asyncHandler(async (req, res) => {
    const ward = db.students.findById(req.params.id);
    if (!ward || ward.parentId !== req.user._id) throw new HttpError(404, "Ward not found");

    const { firstName, lastName, gradeId, subjectIds } = req.body;
    const patch = {};
    if (firstName !== undefined) patch.firstName = firstName;
    if (lastName !== undefined) patch.lastName = lastName;
    if (gradeId !== undefined) patch.gradeId = gradeId;
    if (subjectIds !== undefined) patch.subjects = subjectIds;

    return ok(res, 200, toPublic(db.students.update(ward._id, patch)));
  }),
);

// DELETE /api/wards/:id
router.delete(
  "/:id",
  asyncHandler(async (req, res) => {
    const ward = db.students.findById(req.params.id);
    if (!ward || ward.parentId !== req.user._id) throw new HttpError(404, "Ward not found");
    db.students.delete(ward._id);
    return okMessage(res, 200, "Removed");
  }),
);

module.exports = router;
