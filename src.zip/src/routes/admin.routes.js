const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const ctrl = require("../controllers/admin.controller");

router.use(requireAuth);
router.post("/", requireRole(ROLES.SUPER_ADMIN), ctrl.createAdmin);
router.post("/teachers", requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN), ctrl.createTeacher);
router.post("/transfer-super-admin", requireRole(ROLES.SUPER_ADMIN), ctrl.transferSuperAdmin);
router.get("/staff", requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN), ctrl.listStaff);

module.exports = router;
