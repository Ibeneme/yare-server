const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const { asyncHandler } = require("../utils/httpError");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

const paginate = (rows, { page, limit }) => {
  const p = Math.max(1, Number(page) || 1);
  const l = Math.max(1, Number(limit) || 20);
  return { data: rows.slice((p - 1) * l, (p - 1) * l + l), total: rows.length, page: p };
};

const revenueByCurrency = (rows) => {
  const out = {};
  for (const t of rows) {
    if (t.status !== "success") continue;
    out[t.currency] = out[t.currency] || { total: 0, count: 0 };
    out[t.currency].total += t.amount;
    out[t.currency].count += 1;
  }
  return out;
};

const filterTransactions = (rows, { status, currency, from, to }) => {
  let out = rows;
  if (status) out = out.filter((t) => t.status === status);
  if (currency) out = out.filter((t) => t.currency === currency);
  if (from) out = out.filter((t) => new Date(t.createdAt) >= new Date(from));
  if (to) out = out.filter((t) => new Date(t.createdAt) <= new Date(to));
  return out;
};

// GET /api/transactions/mine — Parent: their own transactions. Raw body (no {success} envelope),
// matching transactions.slice.ts's single `.data` unwrap.
router.get(
  "/mine",
  requireAuth,
  requireRole(ROLES.PARENT),
  asyncHandler(async (req, res) => {
    const rows = filterTransactions(db.transactions.find((t) => t.parentId === req.user._id), req.query);
    res.status(200).json(paginate(rows, req.query));
  }),
);

// GET /api/transactions — Admin: all, with revenue per currency.
router.get(
  "/",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const rows = filterTransactions(db.transactions.all(), req.query);
    const page = paginate(rows, req.query);
    res.status(200).json({ ...page, revenue: revenueByCurrency(rows) });
  }),
);

module.exports = router;
