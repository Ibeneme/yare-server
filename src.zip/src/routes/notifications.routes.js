const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");

router.use(requireAuth);

// GET /api/notifications?unreadOnly=&limit=&page=
router.get(
  "/",
  asyncHandler(async (req, res) => {
    const { unreadOnly, limit, page } = req.query;
    let rows = db.notifications
      .find((n) => n.recipient === req.user._id)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    const totalCount = rows.length;
    const unreadCount = rows.filter((n) => !n.isRead).length;
    if (unreadOnly === "true") rows = rows.filter((n) => !n.isRead);
    const l = Number(limit) || rows.length;
    const p = Math.max(1, Number(page) || 1);
    rows = rows.slice((p - 1) * l, (p - 1) * l + l);
    res.status(200).json({ success: true, data: rows, totalCount, unreadCount });
  }),
);

// PUT /api/notifications/:id/read
router.put(
  "/:id/read",
  asyncHandler(async (req, res) => {
    const note = db.notifications.findById(req.params.id);
    if (!note || note.recipient !== req.user._id) throw new HttpError(404, "Notification not found");
    const updated = db.notifications.update(note._id, { isRead: true });
    return ok(res, 200, updated);
  }),
);

// PUT /api/notifications/read-all
router.put(
  "/read-all",
  asyncHandler(async (req, res) => {
    db.notifications.find((n) => n.recipient === req.user._id && !n.isRead).forEach((n) => db.notifications.update(n._id, { isRead: true }));
    return ok(res, 200, {});
  }),
);

const defaultPrefs = (req) => ({
  email: true,
  classReminders: true,
  feeNotices: true,
  awards: true,
  wards: db.students.find((s) => s.parentId === req.user._id).map((s) => ({
    studentId: s._id,
    name: `${s.firstName} ${s.lastName}`.trim(),
    classReminders: true,
    joinAlerts: true,
  })),
});

// GET /api/notifications/preferences — Parent's own notification preferences.
router.get(
  "/preferences",
  asyncHandler(async (req, res) => {
    const row = db.notificationPrefs.findById(req.user._id);
    return ok(res, 200, row || defaultPrefs(req));
  }),
);

// PUT /api/notifications/preferences
router.put(
  "/preferences",
  asyncHandler(async (req, res) => {
    const { email, classReminders, feeNotices, awards, wards } = req.body;
    const existing = db.notificationPrefs.findById(req.user._id);
    const patch = { _id: req.user._id, email, classReminders, feeNotices, awards, wards };
    const saved = existing ? db.notificationPrefs.update(req.user._id, patch) : db.notificationPrefs.insert(patch);
    return ok(res, 200, saved);
  }),
);

module.exports = router;
