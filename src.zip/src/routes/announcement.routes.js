const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const ctrl = require("../controllers/announcement.controller");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

router.get("/active", requireAuth, ctrl.listActiveAnnouncements);
router.get("/", requireAuth, staffOnly, ctrl.listAllAnnouncements);
router.post("/", requireAuth, staffOnly, ctrl.createAnnouncement);
router.patch("/:id", requireAuth, staffOnly, ctrl.updateAnnouncement);
router.delete("/:id", requireAuth, staffOnly, ctrl.deleteAnnouncement);

module.exports = router;
