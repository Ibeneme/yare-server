const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, ANNOUNCEMENT_KINDS, SEVERITIES } = require("../config/constants");
const { HttpError, asyncHandler, ok, okMessage } = require("../utils/httpError");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

const computeStatus = (a) => {
  const now = new Date();
  if (!a.isActive) return "off";
  if (a.startsAt && now < new Date(a.startsAt)) return "scheduled";
  if (a.endsAt && now > new Date(a.endsAt)) return "ended";
  return "live";
};

const withStatus = (a) => ({ ...a, status: computeStatus(a) });

const isVisibleNow = (a) => {
  if (!a.isActive) return false;
  const now = new Date();
  if (a.startsAt && now < new Date(a.startsAt)) return false;
  if (a.endsAt && now > new Date(a.endsAt)) return false;
  return true;
};

router.use(requireAuth);

// GET /api/announcements/mine — grouped by kind, filtered to this user's audience + active window.
router.get(
  "/mine",
  asyncHandler(async (req, res) => {
    const visible = db.announcements.find((a) => isVisibleNow(a) && (!a.audience?.length || a.audience.includes(req.user.userType)));
    return ok(res, 200, {
      banners: visible.filter((a) => a.kind === "banner").map(withStatus),
      maintenance: visible.filter((a) => a.kind === "maintenance").map(withStatus),
      announcements: visible.filter((a) => a.kind === "announcement").map(withStatus),
    });
  }),
);

// GET /api/announcements?kind= — Admin: everything, with a computed status.
router.get(
  "/",
  staffOnly,
  asyncHandler(async (req, res) => {
    const { kind } = req.query;
    const rows = kind ? db.announcements.find((a) => a.kind === kind) : db.announcements.all();
    return ok(res, 200, rows.map(withStatus));
  }),
);

// POST /api/announcements
router.post(
  "/",
  staffOnly,
  asyncHandler(async (req, res) => {
    const { kind, title, body, severity, linkUrl, linkLabel, dismissible, audience, startsAt, endsAt, isActive, pinned, blocking } = req.body;
    if (!kind || !ANNOUNCEMENT_KINDS.includes(kind)) throw new HttpError(400, "A valid kind is required");
    if (!title) throw new HttpError(400, "title is required");
    const row = db.announcements.insert({
      kind,
      title,
      body: body || "",
      severity: SEVERITIES.includes(severity) ? severity : "info",
      linkUrl: linkUrl || undefined,
      linkLabel: linkLabel || undefined,
      dismissible: dismissible !== false,
      audience: audience || [],
      startsAt: startsAt || null,
      endsAt: endsAt || null,
      isActive: isActive !== false,
      pinned: !!pinned,
      blocking: !!blocking,
    });
    return ok(res, 201, withStatus(row));
  }),
);

// PUT /api/announcements/:id
router.put(
  "/:id",
  staffOnly,
  asyncHandler(async (req, res) => {
    const row = db.announcements.update(req.params.id, req.body);
    if (!row) throw new HttpError(404, "Announcement not found");
    return ok(res, 200, withStatus(row));
  }),
);

// PATCH /api/announcements/:id/toggle — { isActive? } flips if omitted.
router.patch(
  "/:id/toggle",
  staffOnly,
  asyncHandler(async (req, res) => {
    const row = db.announcements.findById(req.params.id);
    if (!row) throw new HttpError(404, "Announcement not found");
    const isActive = req.body.isActive !== undefined ? !!req.body.isActive : !row.isActive;
    const updated = db.announcements.update(row._id, { isActive });
    return ok(res, 200, withStatus(updated));
  }),
);

// DELETE /api/announcements/:id
router.delete(
  "/:id",
  staffOnly,
  asyncHandler(async (req, res) => {
    const row = db.announcements.findById(req.params.id);
    if (!row) throw new HttpError(404, "Announcement not found");
    db.announcements.delete(row._id);
    return ok(res, 200, row._id);
  }),
);

module.exports = router;
