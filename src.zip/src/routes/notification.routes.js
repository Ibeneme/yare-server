const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const ctrl = require("../controllers/notification.controller");

router.use(requireAuth);
router.get("/", ctrl.listMyNotifications);
router.patch("/:id/read", ctrl.markNotificationRead);
router.get("/prefs", ctrl.getMyPrefs);
router.patch("/prefs", ctrl.updateMyPrefs);

module.exports = router;
