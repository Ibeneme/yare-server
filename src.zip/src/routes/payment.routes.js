const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const ctrl = require("../controllers/payment.controller");

// NOTE: the raw webhook route itself is mounted directly in app.js (needs the raw body before
// the JSON parser normalizes it). Everything else here is normal JSON API.
router.post("/checkout", requireAuth, requireRole(ROLES.PARENT), ctrl.initCheckout);
router.get("/transactions/mine", requireAuth, requireRole(ROLES.PARENT), ctrl.myTransactions);
router.get("/transactions/dashboard", requireAuth, requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN), ctrl.transactionsDashboard);

module.exports = router;
