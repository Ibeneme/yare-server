const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, USER_TYPES, TASK_STATUSES, TASK_PRIORITIES } = require("../config/constants");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

const modelFor = (userType) => (userType === USER_TYPES.ADMIN ? "Admin" : "Teacher");
const actorFor = (user) => ({ id: user._id, model: modelFor(user.userType) });

router.use(requireAuth, requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN, ROLES.TEACHER));

const emptyBoard = () => ({ todo: [], in_progress: [], done: [] });

// GET /api/tasks/mine — the signed-in teacher/admin's own board.
router.get(
  "/mine",
  asyncHandler(async (req, res) => {
    const mine = db.tasks.find((t) => t.assignedTo?.id === req.user._id);
    const board = emptyBoard();
    mine.forEach((t) => board[t.status].push(t));
    return ok(res, 200, board);
  }),
);

// POST /api/tasks — create a task for yourself.
router.post(
  "/",
  asyncHandler(async (req, res) => {
    const { title, description, priority, dueDate, labels } = req.body;
    if (!title) throw new HttpError(400, "title is required");
    const actor = actorFor(req.user);
    const task = db.tasks.insert({
      title,
      description: description || "",
      status: "todo",
      priority: TASK_PRIORITIES.includes(priority) ? priority : "medium",
      dueDate: dueDate || undefined,
      labels: labels || [],
      assignedTo: actor,
      createdBy: actor,
      assignedByAdmin: false,
      completedAt: null,
    });
    return ok(res, 201, task);
  }),
);

// POST /api/tasks/assign — { assigneeId, assigneeType, title, ... } — Admin assigns to a teacher/admin.
router.post(
  "/assign",
  staffOnly,
  asyncHandler(async (req, res) => {
    const { assigneeId, assigneeType, title, description, priority, dueDate, labels } = req.body;
    if (!assigneeId || !title) throw new HttpError(400, "assigneeId and title are required");
    const assignee = { id: assigneeId, model: modelFor(assigneeType === "admin" ? USER_TYPES.ADMIN : USER_TYPES.TEACHER) };
    const task = db.tasks.insert({
      title,
      description: description || "",
      status: "todo",
      priority: TASK_PRIORITIES.includes(priority) ? priority : "medium",
      dueDate: dueDate || undefined,
      labels: labels || [],
      assignedTo: assignee,
      createdBy: actorFor(req.user),
      assignedByAdmin: true,
      completedAt: null,
    });
    return ok(res, 201, task);
  }),
);

// GET /api/tasks?assigneeId=&status=&priority=&overdue= — Admin tracker, with per-assignee counts.
router.get(
  "/",
  staffOnly,
  asyncHandler(async (req, res) => {
    const { assigneeId, status, priority, overdue } = req.query;
    let rows = db.tasks.all();
    if (assigneeId) rows = rows.filter((t) => t.assignedTo?.id === assigneeId);
    if (status) rows = rows.filter((t) => t.status === status);
    if (priority) rows = rows.filter((t) => t.priority === priority);
    if (overdue === "true" || overdue === true) {
      const now = new Date();
      rows = rows.filter((t) => t.dueDate && t.status !== "done" && new Date(t.dueDate) < now);
    }
    const perAssignee = {};
    for (const t of db.tasks.all()) {
      const id = t.assignedTo?.id;
      if (!id) continue;
      perAssignee[id] = perAssignee[id] || { todo: 0, in_progress: 0, done: 0 };
      perAssignee[id][t.status] += 1;
    }
    return ok(res, 200, rows, { perAssignee });
  }),
);

// PATCH /api/tasks/:id — { status?, title?, description?, priority?, dueDate?, labels? }
router.patch(
  "/:id",
  asyncHandler(async (req, res) => {
    const task = db.tasks.findById(req.params.id);
    if (!task) throw new HttpError(404, "Task not found");
    const isOwner = task.assignedTo?.id === req.user._id || task.createdBy?.id === req.user._id;
    if (!isOwner && req.user.userType !== USER_TYPES.ADMIN) throw new HttpError(403, "Not authorized");

    const patch = {};
    const { status, title, description, priority, dueDate, labels } = req.body;
    if (status !== undefined) {
      if (!TASK_STATUSES.includes(status)) throw new HttpError(400, "Invalid status");
      patch.status = status;
      patch.completedAt = status === "done" ? new Date().toISOString() : null;
    }
    if (title !== undefined) patch.title = title;
    if (description !== undefined) patch.description = description;
    if (priority !== undefined) patch.priority = priority;
    if (dueDate !== undefined) patch.dueDate = dueDate;
    if (labels !== undefined) patch.labels = labels;

    const updated = db.tasks.update(task._id, patch);
    return ok(res, 200, updated);
  }),
);

// DELETE /api/tasks/:id
router.delete(
  "/:id",
  asyncHandler(async (req, res) => {
    const task = db.tasks.findById(req.params.id);
    if (!task) throw new HttpError(404, "Task not found");
    const isOwner = task.assignedTo?.id === req.user._id || task.createdBy?.id === req.user._id;
    if (!isOwner && req.user.userType !== USER_TYPES.ADMIN) throw new HttpError(403, "Not authorized");
    db.tasks.delete(task._id);
    return ok(res, 200, task._id);
  }),
);

module.exports = router;
