const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, TRIAL_PRESETS } = require("../config/constants");
const { ok } = require("../utils/httpError");
const { getSettings, updateSettings, toPublicSettings } = require("../services/settings.service");

router.use(requireAuth);

// GET /api/platform-settings
router.get(
  "/",
  asyncOk(() => toPublicSettings(getSettings())),
);

// PUT /api/platform-settings/trial — { enabled?, days? }
router.put(
  "/trial",
  requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN),
  (req, res) => {
    const { enabled, days } = req.body;
    const patch = {};
    if (enabled !== undefined) patch.trialEnabled = !!enabled;
    if (days !== undefined) patch.trialDays = Number(days);
    const updated = updateSettings(patch);
    return ok(res, 200, toPublicSettings(updated), { trialPresets: TRIAL_PRESETS });
  },
);

function asyncOk(fn) {
  return (req, res) => ok(res, 200, fn(req, res), { trialPresets: TRIAL_PRESETS });
}

module.exports = router;
