const express = require("express");
const router = express.Router();
const { randomUUID } = require("crypto");
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, FEE_REMINDER_DAYS } = require("../config/constants");
const { FRONTEND_URL } = require("../config/env");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");
const paystack = require("../services/paystack.service");
const access = require("../services/access.service");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

/** Finds the per-grade (or per-subject) price for a student, in the requested currency. */
const priceFor = (student, currency) => {
  const row =
    db.pricing.findOne((p) => p.isActive && p.kind === "grade" && p.refId === student.gradeId) ||
    db.pricing.find((p) => p.isActive && p.kind === "subject" && (student.subjects || []).includes(p.refId))[0];
  if (!row) throw new HttpError(422, `No active pricing is configured for ${student.firstName} ${student.lastName}'s grade yet`);
  const amount = Number(row.prices?.[currency]) || 0;
  return { row, amount };
};

// POST /api/payment/yare/pay/pay-lesson-fee — prices the basket from the Pricing table, returns a checkout session.
router.post(
  "/yare/pay/pay-lesson-fee",
  asyncHandler(async (req, res) => {
    const { email, studentDetails, currency, planName, duration } = req.body;
    if (!email || !Array.isArray(studentDetails) || !studentDetails.length || !currency) {
      throw new HttpError(400, "email, studentDetails and currency are required");
    }
    const students = studentDetails.map(({ _id }) => {
      const s = db.students.findById(_id);
      if (!s) throw new HttpError(404, `Student ${_id} not found`);
      return s;
    });

    const items = [];
    let amount = 0;
    const lessonFeeIds = [];
    const reference = `yh_${randomUUID()}`;
    const durationMonths = Number(duration) || 1;

    for (const student of students) {
      const { row, amount: lineAmount } = priceFor(student, currency);
      amount += lineAmount;
      items.push({ kind: row.kind, refId: row.refId, name: row.name, amount: lineAmount });
      const fee = db.lessonFees.insert({
        studentId: student._id,
        payerId: req.user?._id || null,
        planName: planName || row.name,
        duration: `${durationMonths} month${durationMonths === 1 ? "" : "s"}`,
        amount: lineAmount,
        currency,
        expired: false,
        expiresAt: null,
        reference,
        paid: { isPaid: false },
      });
      lessonFeeIds.push(fee._id);
    }

    const checkout = await paystack.initializeCheckout({
      email,
      amountMinorUnits: Math.round(amount * 100),
      currency,
      metadata: { reference, studentIds: students.map((s) => s._id) },
      callbackUrl: `${FRONTEND_URL}/payment/callback?reference=${reference}`,
    });

    db.transactions.insert({
      reference: checkout.reference,
      parentId: req.user?._id || null,
      payerEmail: email,
      studentIds: students.map((s) => s._id),
      planName: planName || null,
      durationDays: durationMonths * 30,
      items,
      amount,
      currency,
      status: "pending",
      channel: null,
      paidAt: null,
      verifiedBy: null,
    });
    // Keep the lesson fees' reference in sync with the reference Paystack actually assigned.
    if (checkout.reference !== reference) {
      lessonFeeIds.forEach((id) => db.lessonFees.update(id, { reference: checkout.reference }));
    }

    res.status(200).json({
      checkout_url: checkout.authorizationUrl,
      reference: checkout.reference,
      amount,
      currency,
      paymentIds: lessonFeeIds,
    });
  }),
);

const markPaid = (reference) => {
  const tx = db.transactions.findOne((t) => t.reference === reference);
  if (!tx) throw new HttpError(404, "Transaction not found");
  if (tx.status !== "success") {
    db.transactions.update(tx._id, { status: "success", paidAt: new Date().toISOString(), verifiedBy: "callback" });
  }
  const fees = db.lessonFees.find((f) => f.reference === reference);
  const durationMonths = Math.max(1, Math.round((tx.durationDays || 30) / 30));
  const updated = fees.map((fee) => {
    if (fee.paid?.isPaid) return fee;
    const expiresAt = new Date(Date.now() + durationMonths * 30 * 86400000).toISOString();
    const saved = db.lessonFees.update(fee._id, {
      expired: false,
      expiresAt,
      paid: { isPaid: true, timestamp: new Date().toISOString(), paymentMethod: "card", paymentService: "paystack" },
    });
    const student = db.students.findById(fee.studentId);
    if (student) db.students.update(student._id, access.activateSubscriptionPatch({ months: durationMonths }));
    return saved;
  });
  return fees.length ? updated : fees;
};

// GET /api/payment/yare/pay/verify-lesson-fee/:reference — re-checks with Paystack (mirrors the webhook).
router.get(
  "/yare/pay/verify-lesson-fee/:reference",
  asyncHandler(async (req, res) => {
    const { reference } = req.params;
    const result = await paystack.verifyTransaction(reference);
    if (result.status !== "success") {
      return res.status(200).json({ payments: db.lessonFees.find((f) => f.reference === reference) });
    }
    res.status(200).json({ payments: markPaid(reference) });
  }),
);

// POST /api/payment/yare/pay/webhook — Paystack server-to-server notification.
router.post(
  "/yare/pay/webhook",
  asyncHandler(async (req, res) => {
    const signature = req.headers["x-paystack-signature"];
    const raw = req.rawBody || JSON.stringify(req.body);
    if (!paystack.verifyWebhookSignature(raw, signature)) throw new HttpError(401, "Invalid webhook signature");
    const event = req.body;
    if (event?.event === "charge.success") {
      markPaid(event.data.reference);
    }
    res.status(200).json({ received: true });
  }),
);

module.exports = router;
