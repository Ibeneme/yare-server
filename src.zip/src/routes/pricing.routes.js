const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, CURRENCIES } = require("../config/constants");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

const normalizePrices = (prices) => {
  const out = {};
  for (const c of CURRENCIES) out[c] = Number(prices?.[c]) || 0;
  return out;
};

// GET /api/pricing?kind=grade|subject|perk
router.get(
  "/",
  requireAuth,
  asyncHandler(async (req, res) => {
    const { kind } = req.query;
    const rows = kind ? db.pricing.find((p) => p.kind === kind) : db.pricing.all();
    return ok(res, 200, rows);
  }),
);

// POST /api/pricing
router.post(
  "/",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const { kind, refId, name, description, prices, durationDays, isActive } = req.body;
    if (!kind || !name) throw new HttpError(400, "kind and name are required");
    const row = db.pricing.insert({
      kind,
      refId: refId || null,
      name,
      description: description || "",
      prices: normalizePrices(prices),
      durationDays: Number(durationDays) || 30,
      isActive: isActive !== false,
    });
    return ok(res, 201, row);
  }),
);

// PUT /api/pricing/:id
router.put(
  "/:id",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const patch = { ...req.body };
    if (patch.prices) patch.prices = normalizePrices(patch.prices);
    if (patch.durationDays !== undefined) patch.durationDays = Number(patch.durationDays);
    const row = db.pricing.update(req.params.id, patch);
    if (!row) throw new HttpError(404, "Pricing not found");
    return ok(res, 200, row);
  }),
);

// DELETE /api/pricing/:id
router.delete(
  "/:id",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const row = db.pricing.findById(req.params.id);
    if (!row) throw new HttpError(404, "Pricing not found");
    db.pricing.delete(row._id);
    return ok(res, 200, row._id);
  }),
);

module.exports = router;
