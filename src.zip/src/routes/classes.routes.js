const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, USER_TYPES } = require("../config/constants");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

const populatedRef = (collection, id, pick) => {
  if (!id) return id;
  const row = collection.findById(id);
  return row ? { _id: row._id, ...pick(row) } : id;
};

const toClassModel = (cls) => ({
  _id: cls._id,
  title: cls.title,
  subjectId: populatedRef(db.subjects, cls.subjectId, (s) => ({ name: s.name, code: s.code, description: s.description })),
  teacherId: populatedRef(db.teachers, cls.teacherId, (t) => ({ firstName: t.firstName, lastName: t.lastName, email: t.email })),
  studentIds: cls.studentIds || [],
  date: cls.date,
  time: cls.time,
  duration: cls.duration,
  status: cls.status,
  createdAt: cls.createdAt,
  updatedAt: cls.updatedAt,
});

router.use(requireAuth);

// GET /api/class/class/by-user — classes relevant to the signed-in teacher/student.
router.get(
  "/by-user",
  asyncHandler(async (req, res) => {
    const { _id, userType } = req.user;
    let rows;
    if (userType === USER_TYPES.TEACHER) rows = db.classes.find((c) => c.teacherId === _id);
    else if (userType === USER_TYPES.STUDENT) rows = db.classes.find((c) => (c.studentIds || []).includes(_id));
    else rows = db.classes.all();
    return ok(res, 200, rows.map(toClassModel));
  }),
);

// GET /api/class/class
router.get(
  "/",
  asyncHandler(async (req, res) => ok(res, 200, db.classes.all().map(toClassModel))),
);

// POST /api/class/class
router.post(
  "/",
  staffOnly,
  asyncHandler(async (req, res) => {
    const { title, subjectId, teacherId, studentIds, date, time, duration, status } = req.body;
    if (!title || !teacherId) throw new HttpError(400, "title and teacherId are required");
    const cls = db.classes.insert({
      title,
      subjectId: subjectId || null,
      teacherId,
      studentIds: studentIds || [],
      date,
      time,
      duration: Number(duration) || 60,
      status: status || "upcoming",
    });
    return ok(res, 201, toClassModel(cls));
  }),
);

// GET /api/class/class/:param — a classId (single) or a subjectId (filtered list);
// the frontend slice reuses this one path shape for both lookups.
router.get(
  "/:param",
  asyncHandler(async (req, res) => {
    const { param } = req.params;
    const direct = db.classes.findById(param);
    if (direct) return ok(res, 200, toClassModel(direct));
    return ok(res, 200, db.classes.find((c) => c.subjectId === param).map(toClassModel));
  }),
);

// PUT /api/class/class/:id
router.put(
  "/:id",
  staffOnly,
  asyncHandler(async (req, res) => {
    const patch = { ...req.body };
    if (patch.duration !== undefined) patch.duration = Number(patch.duration);
    const cls = db.classes.update(req.params.id, patch);
    if (!cls) throw new HttpError(404, "Class not found");
    return ok(res, 200, toClassModel(cls));
  }),
);

// DELETE /api/class/class/:id
router.delete(
  "/:id",
  staffOnly,
  asyncHandler(async (req, res) => {
    const cls = db.classes.findById(req.params.id);
    if (!cls) throw new HttpError(404, "Class not found");
    db.classes.delete(cls._id);
    return ok(res, 200, { _id: cls._id });
  }),
);

module.exports = router;
