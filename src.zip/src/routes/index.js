const express = require("express");
const router = express.Router();

// People / auth
router.use("/api", require("./identity.routes")); // /auth/login, /create, /all/:userType, /update, /delete, /suspend, /forgot-password, ...
router.use("/api/users", require("./users.routes")); // parent self-registration (OTP) + verify-token
router.use("/api/accounts", require("./accounts.routes")); // /me, /update, /change-password
router.use("/api/admin", require("./legacyAdmin.routes")); // legacy /api/admin/* duplicate, scoped to admins
router.use("/api/wards", require("./wards.routes"));

// Academic structure
router.use("/api/admin/grades", require("./grades.routes"));
router.use("/api/grading-grades", require("./gradeSubjects.routes")); // GET /api/grades/grades/subjects/:gradeId
router.use("/api/subject", require("./subjects.routes"));

// Classes (two live contracts — see each file's header comment)
router.use("/api/admin-classes", require("./adminClasses.routes"));
router.use("/api/class/class", require("./classes.routes"));

// Money
router.use("/api/pricing", require("./pricing.routes"));
router.use("/api/payment", require("./payments.routes"));
router.use("/api/transactions", require("./transactions.routes"));
router.use("/api/access", require("./access.routes"));

// Platform / admin tooling
router.use("/api/super-admin", require("./superAdmin.routes"));
router.use("/api/announcements", require("./announcements.routes"));
router.use("/api/tasks", require("./tasks.routes"));
router.use("/api/awards", require("./awards.routes"));
router.use("/api/awards-for-student/awarding", require("./legacyAwards.routes"));
router.use("/api/notifications", require("./notifications.routes"));
router.use("/api/platform-settings", require("./platformSettings.routes"));

// Classroom REST (live-session signaling itself is Socket.io — see src/sockets)
router.use("/api/classroom", require("./classroomRest.routes"));

// Generic catch-all identity route (GET /api/:userType/:id) — MUST be mounted last so it
// never shadows a more specific domain route above.
router.use("/api", require("./identityCatchAll.routes"));

module.exports = router;
