const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { USER_TYPES } = require("../config/constants");
const { HttpError, asyncHandler, ok, okMessage } = require("../utils/httpError");
const { db } = require("../state");
const { findAccountByEmail, toPublic, roleFor } = require("../services/account.service");
const identity = require("../services/identity.service");

// POST /api/users/register-parent — Section 1, parent self-registration (email-OTP verified).
// Full body -> start a fresh OTP. { email } only -> resend the OTP for that pending signup.
router.post(
  "/register-parent",
  asyncHandler(async (req, res) => {
    const { firstName, lastName, email, phoneNumber, password, confirmPassword } = req.body;

    if (!firstName) {
      // Resend mode.
      if (!email) throw new HttpError(400, "email is required");
      await identity.startOtp({ email, userType: USER_TYPES.PARENT, purpose: "register", subject: "Your Yare Height verification code" });
      return okMessage(res, 200, "OTP resent! Check your email.");
    }

    if (!lastName || !email || !password) throw new HttpError(400, "Missing required fields");
    if (password !== confirmPassword) throw new HttpError(400, "Passwords do not match");
    if (findAccountByEmail(email)) throw new HttpError(409, "An account with this email already exists");

    await identity.startOtp({
      email,
      userType: USER_TYPES.PARENT,
      purpose: "register",
      payload: { firstName, lastName, email, phoneNumber, password },
      subject: "Your Yare Height verification code",
    });
    return okMessage(res, 200, "OTP sent to your email!");
  }),
);

// POST /api/users/register-students-array — verifies the OTP and creates the parent + every child in one shot.
router.post(
  "/register-students-array",
  asyncHandler(async (req, res) => {
    const { email, otp, students = [] } = req.body;
    const record = identity.verifyOtp(email, otp, "register");
    if (!record) throw new HttpError(400, "Invalid OTP");

    const parent = identity.createAccount(USER_TYPES.PARENT, record.payload);
    const created = students.map((s) =>
      identity.createAccount(USER_TYPES.STUDENT, { ...s, parentId: parent._id }),
    );
    identity.consumeOtp(record._id);

    return ok(res, 201, { parent: toPublic(parent), students: created.map(toPublic) }, { message: "Registration complete" });
  }),
);

// GET /api/users/verify-token — whoami, used by verifyAuthToken thunk.
router.get(
  "/verify-token",
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = { ...toPublic(req.user.account), role: roleFor(req.user.account, req.user.userType), userType: req.user.userType };
    return ok(res, 200, { user });
  }),
);

module.exports = router;
