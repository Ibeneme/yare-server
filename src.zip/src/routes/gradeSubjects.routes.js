const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");

const withCounts = (grade) => ({
  ...grade,
  studentCount: db.students.count((s) => s.gradeId === grade._id),
  classCount: db.classes.count((c) => c.gradeId === grade._id),
  subjectCount: db.subjects.count((s) => (Array.isArray(s.gradeLevel) ? s.gradeLevel.includes(grade._id) : s.gradeLevel === grade._id)),
});


// GET /api/grades/grades/subjects/:gradeId — subjects attached to a given grade.
router.get(
  "/grades/subjects/:gradeId",
  requireAuth,
  asyncHandler(async (req, res) => {
    const grade = db.grades.findById(req.params.gradeId);
    if (!grade) throw new HttpError(404, "Grade not found");
    const subjects = db.subjects.find((s) => (Array.isArray(s.gradeLevel) ? s.gradeLevel.includes(grade._id) : s.gradeLevel === grade._id));
    return ok(res, 200, subjects);
  }),
);
router.get("/grades/get-all", requireAuth, asyncHandler(async (req, res) => ok(res, 200, db.grades.all().map(withCounts))));

router.get(
  "/:id",
  requireAuth,
  asyncHandler(async (req, res) => {
    const grade = db.grades.findById(req.params.id);
    if (!grade) throw new HttpError(404, "Grade not found");
    return ok(res, 200, withCounts(grade));
  }),
);


module.exports = router;
