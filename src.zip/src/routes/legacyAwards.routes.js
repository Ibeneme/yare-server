const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");

// Backs the older awards.slice.ts contract (AwardsPage.tsx), which — like
// legacyAdminClasses.slice.ts — reads the list endpoint enveloped but the
// by-id/create/update endpoints as the raw record.
const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN, ROLES.TEACHER);

const toLegacyAward = (a) => {
  const course = a.classId ? db.classes.findById(a.classId) : null;
  const student = a.studentId ? db.students.findById(a.studentId) : null;
  return {
    _id: a._id,
    title: a.title,
    description: a.description,
    studentId: a.studentId,
    teacherId: a.teacherId,
    classId: a.classId,
    createdAt: a.createdAt,
    updatedAt: a.updatedAt,
    course: course ? { title: course.title } : undefined,
    student: student ? { name: `${student.firstName} ${student.lastName}`.trim() } : undefined,
  };
};

router.use(requireAuth, staffOnly);

// GET /api/awards-for-student/awarding — enveloped { data: [...] }.
router.get(
  "/",
  asyncHandler(async (req, res) => ok(res, 200, db.awardGrants.all().map(toLegacyAward))),
);

// GET /api/awards-for-student/awarding/:id — raw record.
router.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const award = db.awardGrants.findById(req.params.id);
    if (!award) throw new HttpError(404, "Award not found");
    res.status(200).json(toLegacyAward(award));
  }),
);

// POST /api/awards-for-student/awarding — raw record.
router.post(
  "/",
  asyncHandler(async (req, res) => {
    const { title, description, studentId, teacherId, classId } = req.body;
    if (!studentId) throw new HttpError(400, "studentId is required");
    const award = db.awardGrants.insert({
      title,
      description: description || "",
      studentId,
      teacherId: teacherId || req.user._id,
      classId: classId || null,
      perk: { kind: "none", expiresAt: null, redeemedAt: null },
    });
    res.status(201).json(toLegacyAward(award));
  }),
);

// PUT /api/awards-for-student/awarding/:id — raw record.
router.put(
  "/:id",
  asyncHandler(async (req, res) => {
    const award = db.awardGrants.update(req.params.id, req.body);
    if (!award) throw new HttpError(404, "Award not found");
    res.status(200).json(toLegacyAward(award));
  }),
);

// DELETE /api/awards-for-student/awarding/:id
router.delete(
  "/:id",
  asyncHandler(async (req, res) => {
    const award = db.awardGrants.findById(req.params.id);
    if (!award) throw new HttpError(404, "Award not found");
    db.awardGrants.delete(award._id);
    res.status(200).json({ success: true, message: "Award deleted" });
  }),
);

module.exports = router;
