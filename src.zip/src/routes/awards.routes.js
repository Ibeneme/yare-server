const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, PERK_KINDS } = require("../config/constants");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");
const accessService = require("../services/access.service");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

router.use(requireAuth);

// GET /api/awards — Admin/Teacher: every award issued.
router.get(
  "/",
  asyncHandler(async (req, res) => ok(res, 200, db.awardGrants.all())),
);

// GET /api/awards/mine — Student/Parent: awards for the signed-in student (or their wards).
router.get(
  "/mine",
  asyncHandler(async (req, res) => {
    const { userType, _id } = req.user;
    let studentIds = [_id];
    if (userType === ROLES.PARENT) studentIds = db.students.find((s) => s.parentId === _id).map((s) => s._id);
    return ok(res, 200, db.awardGrants.find((a) => studentIds.includes(a.studentId)));
  }),
);

// POST /api/awards — { title, description?, studentId, perk }
router.post(
  "/",
  staffOnly,
  asyncHandler(async (req, res) => {
    const { title, description, studentId, perk } = req.body;
    if (!title || !studentId || !perk?.kind) throw new HttpError(400, "title, studentId and perk.kind are required");
    if (!PERK_KINDS.includes(perk.kind)) throw new HttpError(400, "Unknown perk kind");
    if (!db.students.findById(studentId)) throw new HttpError(404, "Student not found");
    const award = db.awardGrants.insert({
      title,
      description: description || "",
      studentId,
      perk: {
        kind: perk.kind,
        discountPercent: perk.discountPercent,
        note: perk.note,
        expiresAt: perk.expiresAt || null,
        redeemedAt: null,
      },
    });
    return ok(res, 201, award);
  }),
);

// PUT /api/awards/:id
router.put(
  "/:id",
  staffOnly,
  asyncHandler(async (req, res) => {
    const award = db.awardGrants.findById(req.params.id);
    if (!award) throw new HttpError(404, "Award not found");
    const patch = { ...req.body };
    if (patch.perk) patch.perk = { ...award.perk, ...patch.perk };
    const updated = db.awardGrants.update(award._id, patch);
    return ok(res, 200, updated);
  }),
);

// DELETE /api/awards/:id
router.delete(
  "/:id",
  staffOnly,
  asyncHandler(async (req, res) => {
    const award = db.awardGrants.findById(req.params.id);
    if (!award) throw new HttpError(404, "Award not found");
    db.awardGrants.delete(award._id);
    return ok(res, 200, award._id);
  }),
);

// POST /api/awards/:id/redeem — Student/Parent redeems a free_month perk.
router.post(
  "/:id/redeem",
  asyncHandler(async (req, res) => {
    const award = db.awardGrants.findById(req.params.id);
    if (!award) throw new HttpError(404, "Award not found");
    if (award.perk.redeemedAt) throw new HttpError(409, "This award has already been redeemed");
    if (award.perk.expiresAt && new Date(award.perk.expiresAt) < new Date()) throw new HttpError(410, "This award has expired");

    if (award.perk.kind === "free_month") {
      const student = db.students.findById(award.studentId);
      if (student) db.students.update(student._id, accessService.activateSubscriptionPatch({ months: 1 }));
    }
    const updated = db.awardGrants.update(award._id, { perk: { ...award.perk, redeemedAt: new Date().toISOString() } });
    return ok(res, 200, { award: updated });
  }),
);

module.exports = router;
