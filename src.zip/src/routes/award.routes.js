const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const ctrl = require("../controllers/award.controller");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

router.use(requireAuth);
router.get("/templates", ctrl.listAwardTemplates);
router.post("/templates", staffOnly, ctrl.createAwardTemplate);
router.post("/issue", staffOnly, ctrl.issueAward);
router.get("/mine", ctrl.listMyAwards); // student
router.get("/ward/:studentId", ctrl.listMyAwards); // parent

module.exports = router;
