const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, USER_TYPES } = require("../config/constants");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");
const { toPublic } = require("../services/account.service");
const identity = require("../services/identity.service");

router.use(requireAuth, requireRole(ROLES.SUPER_ADMIN));

// GET /api/super-admin/admins
router.get(
  "/admins",
  asyncHandler(async (req, res) => ok(res, 200, db.admins.all().map(toPublic))),
);

// POST /api/super-admin/admins
router.post(
  "/admins",
  asyncHandler(async (req, res) => {
    const { email, password, firstName, lastName } = req.body;
    if (!email || !password || !firstName || !lastName) throw new HttpError(400, "email, password, firstName and lastName are required");
    const admin = identity.createAccount(USER_TYPES.ADMIN, { email, password, firstName, lastName, role: ROLES.ADMIN });
    return ok(res, 201, toPublic(admin));
  }),
);

// PATCH /api/super-admin/admins/:id/suspend
router.patch(
  "/admins/:id/suspend",
  asyncHandler(async (req, res) => {
    const admin = db.admins.findById(req.params.id);
    if (!admin) throw new HttpError(404, "Admin not found");
    if (admin.role === ROLES.SUPER_ADMIN) throw new HttpError(403, "Cannot suspend the Super Admin");
    const { suspended } = req.body;
    const updated = db.admins.update(admin._id, { isSuspended: !!suspended });
    return ok(res, 200, { _id: updated._id, isSuspended: updated.isSuspended });
  }),
);

// DELETE /api/super-admin/admins/:id
router.delete(
  "/admins/:id",
  asyncHandler(async (req, res) => {
    const admin = db.admins.findById(req.params.id);
    if (!admin) throw new HttpError(404, "Admin not found");
    if (admin.role === ROLES.SUPER_ADMIN) throw new HttpError(403, "Cannot remove the Super Admin");
    db.admins.delete(admin._id);
    return ok(res, 200, admin._id);
  }),
);

// GET /api/super-admin/transfer/candidates — teachers eligible to become Super Admin.
router.get(
  "/transfer/candidates",
  asyncHandler(async (req, res) =>
    ok(res, 200, db.teachers.all().map((t) => ({ _id: t._id, firstName: t.firstName, lastName: t.lastName, email: t.email }))),
  ),
);

// POST /api/super-admin/transfer — { teacherId }: promotes a teacher to Super Admin, demotes the caller to Admin.
router.post(
  "/transfer",
  asyncHandler(async (req, res) => {
    const { teacherId } = req.body;
    const teacher = db.teachers.findById(teacherId);
    if (!teacher) throw new HttpError(404, "Teacher not found");

    db.teachers.delete(teacher._id);
    db.admins.insert({
      _id: teacher._id,
      email: teacher.email,
      passwordHash: teacher.passwordHash,
      firstName: teacher.firstName,
      lastName: teacher.lastName,
      role: ROLES.SUPER_ADMIN,
      isSuspended: false,
      isDeleted: false,
    });
    const demoted = db.admins.update(req.user._id, { role: ROLES.ADMIN });

    const token = identity.sessionToken(demoted, USER_TYPES.ADMIN);
    return ok(res, 200, {}, { token });
  }),
);

module.exports = router;
