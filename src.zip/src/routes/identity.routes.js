const express = require("express");
const router = express.Router();
const { requireAuth, requireResetToken } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, USER_TYPES } = require("../config/constants");
const { HttpError, asyncHandler, ok, okMessage } = require("../utils/httpError");
const { collectionForUserType, findAccountByEmail, toPublic, roleFor } = require("../services/account.service");
const identity = require("../services/identity.service");
const { hashPassword } = require("../utils/password");
const { db } = require("../state");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

// POST /api/auth/login — { userType, email, password }
router.post(
  "/auth/login",
  asyncHandler(async (req, res) => {
    console.log("[POST /auth/login] Incoming request:", {
      userType: req.body?.userType,
      email: req.body?.email,
      hasPassword: Boolean(req.body?.password),
    });

    const { userType, email, password } = req.body;
    if (!userType || !email || !password) {
      console.log("[POST /auth/login] Missing required fields");
      throw new HttpError(400, "userType, email and password are required");
    }

    const result = identity.login(userType, email, password);
    console.log("[POST /auth/login] identity.login result:", {
      authenticated: Boolean(result),
      accountId: result?.account?._id,
    });
    if (!result) {
      console.log("[POST /auth/login] Invalid credentials for:", { userType, email });
      throw new HttpError(401, "Invalid email or password");
    }

    const user = { ...toPublic(result.account), role: roleFor(result.account, userType), userType };
    console.log("[POST /auth/login] Login success payload:", { userId: user._id, role: user.role, userType });
    return ok(res, 200, user, { message: "Signed in", token: result.token });
  }),
);

// POST /api/create — admin/staff provisions a teacher/admin/student/parent directly.
router.post(
  "/create",
  requireAuth,
  asyncHandler(async (req, res) => {
    console.log("[POST /create] Incoming request:", {
      actor: req.user?._id,
      actorRole: req.user?.role,
      actorUserType: req.user?.userType,
      body: { ...req.body, password: req.body?.password ? "[REDACTED]" : undefined },
    });

    const { userType, ...fields } = req.body;
    if (!Object.values(USER_TYPES).includes(userType)) {
      console.log("[POST /create] Unknown userType:", userType);
      throw new HttpError(400, "Unknown userType");
    }
    if (userType === USER_TYPES.ADMIN && req.user.role !== ROLES.SUPER_ADMIN) {
      console.log("[POST /create] Forbidden: non-super-admin tried creating admin");
      throw new HttpError(403, "Only the Super Admin can create admins");
    }
    if (userType === USER_TYPES.TEACHER && req.user.userType !== USER_TYPES.ADMIN) {
      console.log("[POST /create] Forbidden: non-admin tried creating teacher");
      throw new HttpError(403, "Only an Admin can provision teachers");
    }

    const existing = findAccountByEmail(fields.email);
    console.log("[POST /create] Existing account check:", { email: fields.email, exists: Boolean(existing) });
    if (existing) throw new HttpError(409, "An account with this email already exists");

    const account = identity.createAccount(userType, fields);
    const publicAccount = toPublic(account);
    console.log("[POST /create] Account created:", publicAccount);
    return ok(res, 201, publicAccount);
  }),
);

// GET /api/all/:userType — also doubles as a lookup for the "grade" and "course" (subject)
// catalogues, since several pages reuse this same generic hook for those pickers.
router.get(
  "/all/:userType",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const { userType } = req.params;
    console.log("[GET /all/:userType] Incoming request:", {
      userType,
      actor: req.user?._id,
    });

    if (userType === "grade") {
      const grades = db.grades.all();
      console.log("[GET /all/:userType] Returning grades count:", grades?.length);
      return ok(res, 200, grades);
    }
    if (userType === "course") {
      const subjects = db.subjects.all();
      console.log("[GET /all/:userType] Returning courses/subjects count:", subjects?.length);
      return ok(res, 200, subjects);
    }
    if (!Object.values(USER_TYPES).includes(userType)) {
      console.log("[GET /all/:userType] Unknown userType:", userType);
      throw new HttpError(400, "Unknown userType");
    }

    const users = collectionForUserType(userType).all().map(toPublic);
    console.log("[GET /all/:userType] Returning users count:", { userType, count: users.length });
    return ok(res, 200, users);
  }),
);

// PUT /api/update/:userType/:id
router.put(
  "/update/:userType/:id",
  requireAuth,
  asyncHandler(async (req, res) => {
    const { userType, id } = req.params;
    console.log("[PUT /update/:userType/:id] Incoming request:", {
      userType,
      id,
      actor: req.user?._id,
      actorUserType: req.user?.userType,
      bodyKeys: Object.keys(req.body || {}),
    });

    const isSelf = req.user._id === id && req.user.userType === userType;
    console.log("[PUT /update/:userType/:id] Authorization check:", { isSelf, isAdmin: req.user.userType === USER_TYPES.ADMIN });
    if (!isSelf && req.user.userType !== USER_TYPES.ADMIN) {
      console.log("[PUT /update/:userType/:id] Not authorized");
      throw new HttpError(403, "Not authorized");
    }

    const patch = { ...req.body };
    if (patch.password) {
      console.log("[PUT /update/:userType/:id] Hashing updated password");
      patch.passwordHash = hashPassword(patch.password);
    }
    delete patch.password;

    const updated = collectionForUserType(userType).update(id, patch);
    console.log("[PUT /update/:userType/:id] Update result:", { found: Boolean(updated), id });
    if (!updated) throw new HttpError(404, "Not found");

    const publicUpdated = toPublic(updated);
    console.log("[PUT /update/:userType/:id] Updated account:", publicUpdated);
    return ok(res, 200, publicUpdated);
  }),
);

// DELETE /api/delete/:id — { userType } in the body (soft delete).
router.delete(
  "/delete/:id",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const { userType } = req.body;
    console.log("[DELETE /delete/:id] Incoming request:", {
      id: req.params.id,
      userType,
      actor: req.user?._id,
    });

    const updated = collectionForUserType(userType).update(req.params.id, { isDeleted: true });
    console.log("[DELETE /delete/:id] Soft delete result:", { id: req.params.id, found: Boolean(updated) });
    if (!updated) throw new HttpError(404, "Not found");

    console.log("[DELETE /delete/:id] Deleted user:", req.params.id);
    return okMessage(res, 200, "Deleted");
  }),
);

// PUT /api/suspend/:id — { userType }
router.put(
  "/suspend/:id",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const { userType } = req.body;
    console.log("[PUT /suspend/:id] Incoming request:", {
      id: req.params.id,
      userType,
      actor: req.user?._id,
    });

    const account = collectionForUserType(userType).findById(req.params.id);
    console.log("[PUT /suspend/:id] Found account:", {
      found: Boolean(account),
      currentSuspended: account?.isSuspended,
    });
    if (!account) throw new HttpError(404, "Not found");

    const updated = collectionForUserType(userType).update(account._id, { isSuspended: !account.isSuspended });
    const statusMessage = updated.isSuspended ? "Suspended" : "Restored";
    console.log("[PUT /suspend/:id] New suspension status:", { id: account._id, statusMessage });
    return okMessage(res, 200, statusMessage);
  }),
);

// POST /api/forgot-password — { userType, email }
router.post(
  "/forgot-password",
  asyncHandler(async (req, res) => {
    const { userType, email } = req.body;
    console.log("[POST /forgot-password] Incoming request:", { userType, email });

    const account = findAccountByEmail(email, userType);
    console.log("[POST /forgot-password] Account lookup:", { found: Boolean(account) });
    if (!account) throw new HttpError(404, "No account with that email");

    await identity.startOtp({ email, userType, purpose: "reset", subject: "Reset your Yare Height password" });
    console.log("[POST /forgot-password] OTP sent to:", email);
    return okMessage(res, 200, "OTP sent to your email");
  }),
);

// POST /api/resend-otp — { userType, email }
router.post(
  "/resend-otp",
  asyncHandler(async (req, res) => {
    const { userType, email } = req.body;
    console.log("[POST /resend-otp] Incoming request:", { userType, email });

    await identity.startOtp({ email, userType, purpose: "reset", subject: "Your Yare Height verification code" });
    console.log("[POST /resend-otp] OTP resent to:", email);
    return okMessage(res, 200, "OTP resent");
  }),
);

// POST /api/verify-forgot-password — { email, otp } -> { data: { resetToken } }
router.post(
  "/verify-forgot-password",
  asyncHandler(async (req, res) => {
    const { email, otp } = req.body;
    console.log("[POST /verify-forgot-password] Incoming request:", { email, hasOtp: Boolean(otp) });

    const record = identity.verifyOtp(email, otp, "reset");
    console.log("[POST /verify-forgot-password] OTP verification:", {
      valid: Boolean(record),
      recordId: record?._id,
      userType: record?.userType,
    });
    if (!record) throw new HttpError(400, "Invalid or expired OTP");

    identity.consumeOtp(record._id);
    const token = identity.resetToken(email, record.userType);
    console.log("[POST /verify-forgot-password] OTP consumed & reset token issued for:", email);
    return ok(res, 200, { resetToken: token });
  }),
);

// POST /api/reset-password — Bearer <resetToken>, body { userType, email, password }
router.post(
  "/reset-password",
  requireResetToken,
  asyncHandler(async (req, res) => {
    const { userType, email, password } = req.body;
    console.log("[POST /reset-password] Incoming request:", {
      userType,
      email,
      tokenEmail: req.resetPayload?.email,
      hasPassword: Boolean(password),
    });

    if (req.resetPayload.email !== email) {
      console.log("[POST /reset-password] Token email mismatch");
      throw new HttpError(401, "Reset token doesn't match this email");
    }

    const account = collectionForUserType(userType).findOne((u) => u.email === email);
    console.log("[POST /reset-password] Account lookup:", { found: Boolean(account), accountId: account?._id });
    if (!account) throw new HttpError(404, "Account not found");

    collectionForUserType(userType).update(account._id, { passwordHash: hashPassword(password) });
    console.log("[POST /reset-password] Password reset succeeded for:", { accountId: account._id, email });
    return okMessage(res, 200, "Password reset");
  }),
);

module.exports = router;