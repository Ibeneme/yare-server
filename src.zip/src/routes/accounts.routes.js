const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { asyncHandler, HttpError } = require("../utils/httpError");
const { comparePassword, hashPassword } = require("../utils/password");
const { collectionForUserType, toPublic } = require("../services/account.service");

router.use(requireAuth);

// GET /api/accounts/me — accountsSlice.fetchUser expects { userType, data: User[] }.
router.get(
  "/me",
  asyncHandler(async (req, res) => {
    res.json({ success: true, userType: req.user.userType, data: [toPublic(req.user.account)] });
  }),
);

// PUT /api/accounts/update
router.put(
  "/update",
  asyncHandler(async (req, res) => {
    const patch = { ...req.body };
    delete patch.password;
    delete patch.email;
    const updated = collectionForUserType(req.user.userType).update(req.user._id, patch);
    res.json({ success: true, userType: req.user.userType, data: [toPublic(updated)] });
  }),
);

// POST /api/accounts/change-password
router.post(
  "/change-password",
  asyncHandler(async (req, res) => {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) throw new HttpError(400, "currentPassword and newPassword are required");
    if (!comparePassword(currentPassword, req.user.account.passwordHash)) throw new HttpError(400, "Current password is incorrect");
    collectionForUserType(req.user.userType).update(req.user._id, { passwordHash: hashPassword(newPassword) });
    res.json({ success: true, message: "Password updated" });
  }),
);

module.exports = router;
