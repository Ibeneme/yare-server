const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const { HttpError, asyncHandler, ok, okMessage } = require("../utils/httpError");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

const withCounts = (grade) => ({
  ...grade,
  studentCount: db.students.count((s) => s.gradeId === grade._id),
  classCount: db.classes.count((c) => c.gradeId === grade._id),
  subjectCount: db.subjects.count((s) => (Array.isArray(s.gradeLevel) ? s.gradeLevel.includes(grade._id) : s.gradeLevel === grade._id)),
});

// Section 2 — Grade & Level Management (Admins configure global grades/levels).
router.get("/", requireAuth, asyncHandler(async (req, res) => ok(res, 200, db.grades.all().map(withCounts))));

router.post(
  "/",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const { title, description } = req.body;
    if (!title) throw new HttpError(400, "title is required");
    const grade = db.grades.insert({ title, description: description || "", studentIds: [], classIds: [], subjectIds: [] });
    return ok(res, 201, withCounts(grade));
  }),
);

router.get(
  "/:id",
  requireAuth,
  asyncHandler(async (req, res) => {
    const grade = db.grades.findById(req.params.id);
    if (!grade) throw new HttpError(404, "Grade not found");
    return ok(res, 200, withCounts(grade));
  }),
);

router.put(
  "/:id",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const grade = db.grades.update(req.params.id, req.body);
    if (!grade) throw new HttpError(404, "Grade not found");
    return ok(res, 200, withCounts(grade));
  }),
);

router.delete(
  "/:id",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const grade = db.grades.findById(req.params.id);
    if (!grade) throw new HttpError(404, "Grade not found");
    db.grades.delete(grade._id);
    return ok(res, 200, grade);
  }),
);

module.exports = router;
