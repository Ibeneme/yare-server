const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const ctrl = require("../controllers/settings.controller");
const subCtrl = require("../controllers/subscription.controller");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

router.use(requireAuth);
router.get("/", staffOnly, ctrl.readSettings);
router.patch("/trial", staffOnly, ctrl.updateTrialSettings);
router.patch("/maintenance", requireRole(ROLES.SUPER_ADMIN), ctrl.updateMaintenance);
router.post("/grace", staffOnly, ctrl.grantGrace);

router.get("/subscription/mine", subCtrl.getMySubscription);

module.exports = router;
