const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const ctrl = require("../controllers/ward.controller");

router.use(requireAuth);
router.post("/", requireRole(ROLES.PARENT), ctrl.addWard);
router.get("/", requireRole(ROLES.PARENT), ctrl.listMyWards);
router.patch("/:id/enrollment", requireRole(ROLES.PARENT), ctrl.updateWardEnrollment);
router.patch("/:id/profile", ctrl.updateWardProfile); // parent or the student themselves

module.exports = router;
