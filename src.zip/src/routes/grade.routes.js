const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const ctrl = require("../controllers/grade.controller");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

router.get("/", requireAuth, ctrl.listGrades);
router.post("/", requireAuth, staffOnly, ctrl.createGrade);
router.patch("/:id", requireAuth, staffOnly, ctrl.updateGrade);
router.delete("/:id", requireAuth, staffOnly, ctrl.deleteGrade);

router.get("/subjects/all", requireAuth, ctrl.listSubjects);
router.post("/subjects", requireAuth, staffOnly, ctrl.createSubject);
router.patch("/subjects/:id", requireAuth, staffOnly, ctrl.updateSubject);
router.delete("/subjects/:id", requireAuth, staffOnly, ctrl.deleteSubject);

module.exports = router;
