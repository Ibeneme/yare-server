const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { USER_TYPES } = require("../config/constants");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");
const { collectionForUserType, toPublic } = require("../services/account.service");

// GET /api/:userType/:id — generic fetch-by-id. Mounted LAST in routes/index.js so it never
// shadows a more specific domain route (e.g. /api/wards, /api/pricing, ...).
router.get(
  "/:userType/:id",
  requireAuth,
  asyncHandler(async (req, res) => {
    const { userType, id } = req.params;
    if (!Object.values(USER_TYPES).includes(userType)) throw new HttpError(404, "Not found");
    const account = collectionForUserType(userType).findById(id);
    if (!account) throw new HttpError(404, "Not found");
    return ok(res, 200, toPublic(account));
  }),
);

module.exports = router;
