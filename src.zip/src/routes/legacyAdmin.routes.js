const express = require("express");
const router = express.Router();
const {
  requireAuth,
  requireResetToken,
} = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, USER_TYPES } = require("../config/constants");
const {
  HttpError,
  asyncHandler,
  ok,
  okMessage,
} = require("../utils/httpError");
const { db } = require("../state");
const {
  findAccountByEmail,
  toPublic,
  roleFor,
} = require("../services/account.service");
const identity = require("../services/identity.service");
const { hashPassword } = require("../utils/password");

// Legacy admin-only duplicate of the generic identity endpoints — kept because auth.slice.ts
// (UserManagement / SettingsLayout) still calls these directly under /api/admin.
const superAdminOnly = requireRole(ROLES.SUPER_ADMIN);
const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

// GET /api/admin/teachers — every teacher account.
router.get(
  "/teachers",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) =>
    ok(res, 200, db.teachers.all().map(toPublic)),
  ),
);

router.post(
  "/register",
  requireAuth,
  superAdminOnly,
  asyncHandler(async (req, res) => {
    const { email, password, role } = req.body;
    if (findAccountByEmail(email))
      throw new HttpError(409, "An account with this email already exists");
    const account = identity.createAccount(USER_TYPES.ADMIN, {
      ...req.body,
      asSuperAdmin: role === ROLES.SUPER_ADMIN,
    });
    return ok(res, 201, toPublic(account));
  }),
);

router.post(
  "/login",
  asyncHandler(async (req, res) => {
    const { email, password } = req.body;
    const result = identity.login(USER_TYPES.ADMIN, email, password);
    if (!result) throw new HttpError(401, "Invalid email or password");
    return ok(
      res,
      200,
      {
        ...toPublic(result.account),
        role: roleFor(result.account, USER_TYPES.ADMIN),
      },
      { token: result.token },
    );
  }),
);

router.post(
  "/forgot-password",
  asyncHandler(async (req, res) => {
    await identity.startOtp({
      email: req.body.email,
      userType: USER_TYPES.ADMIN,
      purpose: "reset",
      subject: "Reset your Yare Height password",
    });
    return okMessage(res, 200, "OTP sent to your email");
  }),
);
router.post(
  "/resend-otp",
  asyncHandler(async (req, res) => {
    await identity.startOtp({
      email: req.body.email,
      userType: USER_TYPES.ADMIN,
      purpose: "reset",
      subject: "Your Yare Height verification code",
    });
    return okMessage(res, 200, "OTP resent");
  }),
);
router.post(
  "/verify-forgot-password",
  asyncHandler(async (req, res) => {
    const record = identity.verifyOtp(req.body.email, req.body.otp, "reset");
    if (!record) throw new HttpError(400, "Invalid or expired OTP");
    identity.consumeOtp(record._id);
    return okMessage(
      res,
      200,
      identity.resetToken(req.body.email, USER_TYPES.ADMIN),
    );
  }),
);
router.post(
  "/reset-password",
  requireResetToken,
  asyncHandler(async (req, res) => {
    const account = db.admins.findOne((a) => a.email === req.body.email);
    if (!account) throw new HttpError(404, "Account not found");
    db.admins.update(account._id, {
      passwordHash: hashPassword(req.body.password),
    });
    return okMessage(res, 200, "Password reset");
  }),
);

router.get(
  "/",
  requireAuth,
  superAdminOnly,
  asyncHandler(async (req, res) => ok(res, 200, db.admins.all().map(toPublic))),
);

router.get(
  "/:userType/:id",
  requireAuth,
  superAdminOnly,
  asyncHandler(async (req, res) => {
    const account = db.admins.findById(req.params.id);
    if (!account) throw new HttpError(404, "Not found");
    return ok(res, 200, toPublic(account));
  }),
);

router.put(
  "/suspend/:id",
  requireAuth,
  superAdminOnly,
  asyncHandler(async (req, res) => {
    const account = db.admins.findById(req.params.id);
    if (!account) throw new HttpError(404, "Not found");
    const updated = db.admins.update(account._id, {
      isSuspended: !account.isSuspended,
    });
    return okMessage(res, 200, updated.isSuspended ? "Suspended" : "Restored");
  }),
);

router.delete(
  "/delete/:id",
  requireAuth,
  superAdminOnly,
  asyncHandler(async (req, res) => {
    db.admins.update(req.params.id, { isDeleted: true });
    return okMessage(res, 200, "Deleted");
  }),
);

router.put(
  "/self-update/:id",
  requireAuth,
  asyncHandler(async (req, res) => {
    if (req.user._id !== req.params.id)
      throw new HttpError(403, "Not authorized");
    const { email, password, role } = req.body;
    const patch = {};
    if (email) patch.email = email;
    if (password) patch.passwordHash = hashPassword(password);
    if (role && req.user.role === ROLES.SUPER_ADMIN) patch.role = role;
    const updated = db.admins.update(req.user._id, patch);
    return ok(res, 200, toPublic(updated));
  }),
);

router.post(
  "/add-admin",
  requireAuth,
  superAdminOnly,
  asyncHandler(async (req, res) => {
    const { email, password, role, firstName, lastName } = req.body;
    if (findAccountByEmail(email))
      throw new HttpError(409, "An account with this email already exists");
    const account = identity.createAccount(USER_TYPES.ADMIN, {
      email,
      password,
      firstName,
      lastName,
      asSuperAdmin: role === ROLES.SUPER_ADMIN,
    });
    return ok(res, 201, toPublic(account), {
      message: "Admin created successfully",
    });
  }),
);

module.exports = router;
