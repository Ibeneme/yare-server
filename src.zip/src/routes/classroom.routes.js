const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const ctrl = require("../controllers/classroom.controller");

router.use(requireAuth);
router.get("/:classId/join", ctrl.getJoinInfo);
router.post("/:classId/assignments", ctrl.postAssignment);
router.get("/:classId/assignments", ctrl.listAssignments);
router.post("/assignments/:assignmentId/submit", ctrl.submitAssignment);

module.exports = router;
