const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const ctrl = require("../controllers/auth.controller");

router.post("/signup/parent", ctrl.signupParent);
router.post("/signup/student", ctrl.signupStudent);
router.post("/login", ctrl.login);
router.get("/me", requireAuth, ctrl.me);
router.post("/change-password", requireAuth, ctrl.changePassword);

module.exports = router;
