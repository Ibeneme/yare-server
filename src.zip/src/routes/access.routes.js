const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES, GRACE_DURATIONS } = require("../config/constants");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");
const access = require("../services/access.service");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

const ensureGrace = (student) => {
  const patch = access.ensureExpiryGrace(student);
  return patch ? db.students.update(student._id, patch) : student;
}

// GET /api/access/me — Student: neutral view, never mentions fees.
router.get(
  "/me",
  requireAuth,
  requireRole(ROLES.STUDENT),
  asyncHandler(async (req, res) => {
    const student = ensureGrace(db.students.findById(req.user._id));
    return ok(res, 200, access.toStudentView(access.computeAccess(student)));
  }),
);

// GET /api/access/wards — Parent: real access state of each ward.
router.get(
  "/wards",
  requireAuth,
  requireRole(ROLES.PARENT),
  asyncHandler(async (req, res) => {
    const wards = db.students.find((s) => s.parentId === req.user._id).map(ensureGrace);
    const rows = wards.map((w) => {
      const a = access.computeAccess(w);
      return {
        studentId: w._id,
        name: `${w.firstName} ${w.lastName}`.trim(),
        access: a,
        daysLeft: access.daysLeft(a),
        needsRenewal: access.needsRenewal(a),
      };
    });
    return ok(res, 200, rows);
  }),
);

// GET /api/access/students?state=&q= — Admin: every student with their access state.
router.get(
  "/students",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const { state, q } = req.query;
    let students = db.students.all().map(ensureGrace);
    if (q) {
      const needle = String(q).toLowerCase();
      students = students.filter((s) => `${s.firstName} ${s.lastName} ${s.email}`.toLowerCase().includes(needle));
    }
    let rows = students.map((s) => ({
      _id: s._id,
      firstName: s.firstName,
      lastName: s.lastName,
      email: s.email,
      trialEndsAt: s.trialEndsAt,
      trialDays: s.trialDays,
      adminGraceUntil: s.adminGraceUntil,
      adminGraceDuration: s.adminGraceDuration,
      access: access.computeAccess(s),
    }));
    if (state) rows = rows.filter((r) => r.access.reason === state);
    return ok(res, 200, rows, { options: Object.keys(GRACE_DURATIONS) });
  }),
);

// POST /api/access/students/:id/grace — Admin Grace Override Toggle.
router.post(
  "/students/:id/grace",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const student = db.students.findById(req.params.id);
    if (!student) throw new HttpError(404, "Student not found");
    const { duration } = req.body;
    if (!GRACE_DURATIONS[duration]) throw new HttpError(400, "Unknown grace duration");
    const updated = db.students.update(student._id, access.adminGracePatch(duration));
    return ok(res, 200, {
      _id: updated._id,
      firstName: updated.firstName,
      lastName: updated.lastName,
      email: updated.email,
      trialEndsAt: updated.trialEndsAt,
      trialDays: updated.trialDays,
      adminGraceUntil: updated.adminGraceUntil,
      adminGraceDuration: updated.adminGraceDuration,
      access: access.computeAccess(updated),
    });
  }),
);

// DELETE /api/access/students/:id/grace — revoke an admin grace override.
router.delete(
  "/students/:id/grace",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const student = db.students.findById(req.params.id);
    if (!student) throw new HttpError(404, "Student not found");
    const updated = db.students.update(student._id, { adminGraceUntil: null, adminGraceDuration: null });
    return ok(res, 200, { _id: updated._id, access: access.computeAccess(updated) });
  }),
);

module.exports = router;
