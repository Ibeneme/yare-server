const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const ctrl = require("../controllers/task.controller");

router.use(requireAuth);
router.get("/", ctrl.listTasks);
router.post("/", ctrl.createTask);
router.patch("/:id", ctrl.updateTask);
router.delete("/:id", ctrl.deleteTask);

module.exports = router;
