const express = require("express");
const router = express.Router();
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const ctrl = require("../controllers/class.controller");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

router.use(requireAuth);
router.get("/", ctrl.listClasses);
router.post("/", staffOnly, ctrl.createClass);
router.patch("/:id", staffOnly, ctrl.updateClass);
router.delete("/:id", staffOnly, ctrl.deleteClass);

router.get("/groups/all", ctrl.listGroups);
router.post("/groups", staffOnly, ctrl.createGroup);

module.exports = router;
