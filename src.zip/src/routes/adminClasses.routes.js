const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");

// This router backs the legacy /api/admin-classes contract used by ManageClassesPage,
// ClassDetailsPage, ClassCardList, ClassFormPage and AwardsPage. Unlike the rest of this
// API, that slice (legacyAdminClasses.slice.ts) reads list endpoints as { data: [...] }
// but reads single-record endpoints (by id, create, update) as the RAW record with no
// envelope — so those three deliberately skip the `ok()` wrapper below.
const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

const refOf = (collection, id, pick) => {
  if (!id) return undefined;
  const row = collection.findById(id);
  if (!row) return { _id: id };
  const out = { _id: row._id };
  Object.assign(out, pick(row));
  return out;
};

const toAdminClassData = (cls) => {
  const courseId = refOf(db.subjects, cls.subjectId, (s) => ({ title: s.name, name: s.name }));
  const teacherId = refOf(db.teachers, cls.teacherId, (t) => ({ firstName: t.firstName, lastName: t.lastName }));
  const gradeId = refOf(db.grades, cls.gradeId, (g) => ({ title: g.title, name: g.title }));
  const enrolledStudents = (cls.studentIds || [])
    .map((id) => db.students.findById(id))
    .filter(Boolean)
    .map((s) => ({ _id: s._id, name: `${s.firstName} ${s.lastName}`.trim() }));
  return {
    _id: cls._id,
    title: cls.title,
    courseId,
    course: courseId ? { title: courseId.title } : undefined,
    departmentId: undefined,
    teacherId,
    gradeId,
    date: cls.date,
    time: cls.time,
    duration: cls.duration,
    status: cls.status,
    enrolledStudents,
    createdAt: cls.createdAt,
    updatedAt: cls.updatedAt,
  };
};

const buildClassPatch = (body) => {
  const patch = {};
  if (body.title !== undefined) patch.title = body.title;
  if (body.courseId !== undefined) patch.subjectId = body.courseId;
  if (body.teacherId !== undefined) patch.teacherId = body.teacherId;
  if (body.gradeId !== undefined) patch.gradeId = body.gradeId;
  if (body.date !== undefined) patch.date = body.date;
  if (body.time !== undefined) patch.time = body.time;
  if (body.duration !== undefined) patch.duration = Number(body.duration);
  if (body.status !== undefined) patch.status = body.status;
  return patch;
};

router.use(requireAuth);

// GET /api/admin-classes
router.get(
  "/",
  asyncHandler(async (req, res) => ok(res, 200, db.classes.all().map(toAdminClassData))),
);

// GET /api/admin-classes/teacher/:teacherId
router.get(
  "/teacher/:teacherId",
  asyncHandler(async (req, res) =>
    ok(res, 200, db.classes.find((c) => c.teacherId === req.params.teacherId).map(toAdminClassData)),
  ),
);

// GET /api/admin-classes/:id — raw record, no envelope (matches the slice's fetchClassById).
router.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const cls = db.classes.findById(req.params.id);
    if (!cls) throw new HttpError(404, "Class not found");
    res.status(200).json(toAdminClassData(cls));
  }),
);

// POST /api/admin-classes — raw record, no envelope.
router.post(
  "/",
  staffOnly,
  asyncHandler(async (req, res) => {
    const { title, courseId, teacherId } = req.body;
    if (!title || !courseId || !teacherId) throw new HttpError(400, "title, courseId and teacherId are required");
    const cls = db.classes.insert({
      ...buildClassPatch(req.body),
      studentIds: [],
      status: req.body.status || "upcoming",
    });
    res.status(201).json(toAdminClassData(cls));
  }),
);

// PUT /api/admin-classes/:id — raw record, no envelope.
router.put(
  "/:id",
  staffOnly,
  asyncHandler(async (req, res) => {
    const cls = db.classes.update(req.params.id, buildClassPatch(req.body));
    if (!cls) throw new HttpError(404, "Class not found");
    res.status(200).json(toAdminClassData(cls));
  }),
);

// DELETE /api/admin-classes/:id
router.delete(
  "/:id",
  staffOnly,
  asyncHandler(async (req, res) => {
    const cls = db.classes.findById(req.params.id);
    if (!cls) throw new HttpError(404, "Class not found");
    db.classes.delete(cls._id);
    res.status(200).json({ success: true, message: "Class deleted" });
  }),
);

module.exports = router;
