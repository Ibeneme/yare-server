const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { ROLES, USER_TYPES, HOST_USER_TYPES } = require("../config/constants");
const { HttpError, asyncHandler, ok } = require("../utils/httpError");
const { rooms } = require("../sockets/roomState");

router.use(requireAuth);

const toClassSession = (cls) => ({
  _id: cls._id,
  title: cls.title,
  subjectId: cls.subjectId,
  gradeId: cls.gradeId,
  audience: cls.audience || "students",
  groupIds: cls.groupIds || [],
  studentIds: cls.studentIds || [],
  teacherId: cls.teacherId,
  schedules: cls.schedules || [
    { frequency: "none", timeSlots: [{ startTime: cls.time, endTime: cls.time }], daysOfWeek: [], daysOfMonth: [], specificDates: [], startDate: cls.date, endDate: cls.date },
  ],
});

const canAccessClass = (user, cls) => {
  if (user.userType === USER_TYPES.ADMIN) return true;
  if (user.userType === USER_TYPES.TEACHER) return cls.teacherId === user._id;
  if (user.userType === USER_TYPES.STUDENT) return (cls.studentIds || []).includes(user._id);
  return false;
};

// GET /api/classroom/my-classes
router.get(
  "/my-classes",
  asyncHandler(async (req, res) => {
    const { _id, userType } = req.user;
    let rows;
    if (userType === USER_TYPES.TEACHER) rows = db.classes.find((c) => c.teacherId === _id);
    else if (userType === USER_TYPES.STUDENT) rows = db.classes.find((c) => (c.studentIds || []).includes(_id));
    else rows = db.classes.all();
    return ok(res, 200, rows.map(toClassSession));
  }),
);

// GET /api/classroom/:id/access
router.get(
  "/:id/access",
  asyncHandler(async (req, res) => {
    const cls = db.classes.findById(req.params.id);
    if (!cls) throw new HttpError(404, "Class not found");
    if (!canAccessClass(req.user, cls)) throw new HttpError(403, "You don't have access to this class");

    const isHost = HOST_USER_TYPES.includes(req.user.userType) && (req.user.userType === USER_TYPES.ADMIN || cls.teacherId === req.user._id);
    const room = rooms[cls._id];
    const access = {
      role: req.user.role,
      isHost,
      live: !!room && room.participants.size > 0,
      class: { _id: cls._id, title: cls.title },
    };
    return ok(
      res,
      200,
      access,
      {
        room: {
          screenSharerId: room?.screenShare || null,
          participants: room ? Array.from(room.participants.values()) : [],
        },
      },
    );
  }),
);

// GET /api/classroom/:id/assignments
router.get(
  "/:id/assignments",
  asyncHandler(async (req, res) => {
    const cls = db.classes.findById(req.params.id);
    if (!cls) throw new HttpError(404, "Class not found");
    if (!canAccessClass(req.user, cls)) throw new HttpError(403, "You don't have access to this class");
    const items = db.classAssignments.find((a) => a.classId === cls._id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return ok(res, 200, items);
  }),
);

// POST /api/classroom/:id/assignments — { title, instructions?, dueDate? }
router.post(
  "/:id/assignments",
  asyncHandler(async (req, res) => {
    const cls = db.classes.findById(req.params.id);
    if (!cls) throw new HttpError(404, "Class not found");
    if (!(req.user.userType === USER_TYPES.ADMIN || cls.teacherId === req.user._id)) throw new HttpError(403, "Only the class's teacher can post an assignment");
    const { title, instructions, dueDate } = req.body;
    if (!title) throw new HttpError(400, "title is required");
    const room = rooms[cls._id];
    const assignment = db.classAssignments.insert({
      classId: cls._id,
      teacherId: cls.teacherId,
      title,
      instructions: instructions || "",
      dueDate: dueDate || null,
      postedDuringLive: !!room && room.participants.size > 0,
    });
    const io = req.app.get("io");
    if (io) io.to(`class:${cls._id}`).emit("assignment:new", assignment);
    return ok(res, 201, assignment);
  }),
);

// GET /api/classroom/:id/notes
router.get(
  "/:id/notes",
  asyncHandler(async (req, res) => {
    const cls = db.classes.findById(req.params.id);
    if (!cls) throw new HttpError(404, "Class not found");
    if (!canAccessClass(req.user, cls)) throw new HttpError(403, "You don't have access to this class");
    const note = db.classroomNotes.findOne((n) => n.classId === cls._id) || { content: "", version: 0, lastEditedBy: undefined };
    return ok(res, 200, { content: note.content, version: note.version, lastEditedBy: note.lastEditedBy });
  }),
);

module.exports = router;
