const express = require("express");
const router = express.Router();
const { db } = require("../state");
const { requireAuth } = require("../middlewares/auth.middleware");
const { requireRole } = require("../middlewares/role.middleware");
const { ROLES } = require("../config/constants");
const { HttpError, asyncHandler, ok, okMessage } = require("../utils/httpError");

const staffOnly = requireRole(ROLES.ADMIN, ROLES.SUPER_ADMIN);

const asArray = (v) => (Array.isArray(v) ? v : v ? [v] : []);

// GET /api/subject/token — subjects visible to the caller (teacher: assigned; others: all).
router.get(
  "/token",
  requireAuth,
  asyncHandler(async (req, res) => {
    const all = db.subjects.all();
    if (req.user.role === ROLES.TEACHER) {
      return ok(res, 200, all.filter((s) => asArray(s.teachers).includes(req.user._id)));
    }
    return ok(res, 200, all);
  }),
);

router.post(
  "/",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const { name, code, description, gradeLevel, teachers, children } = req.body;
    if (!name) throw new HttpError(400, "name is required");
    const subject = db.subjects.insert({
      name,
      code: code || "",
      description: description || "",
      gradeLevel: asArray(gradeLevel),
      teachers: asArray(teachers),
      children: asArray(children),
      isActive: true,
    });
    return ok(res, 201, subject);
  }),
);

router.get(
  "/:id",
  requireAuth,
  asyncHandler(async (req, res) => {
    const subject = db.subjects.findById(req.params.id);
    if (!subject) throw new HttpError(404, "Subject not found");
    return ok(res, 200, subject);
  }),
);

router.put(
  "/:id",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const patch = { ...req.body };
    if (patch.gradeLevel !== undefined) patch.gradeLevel = asArray(patch.gradeLevel);
    if (patch.teachers !== undefined) patch.teachers = asArray(patch.teachers);
    if (patch.children !== undefined) patch.children = asArray(patch.children);
    const subject = db.subjects.update(req.params.id, patch);
    if (!subject) throw new HttpError(404, "Subject not found");
    return ok(res, 200, subject);
  }),
);

router.delete(
  "/:id",
  requireAuth,
  staffOnly,
  asyncHandler(async (req, res) => {
    const subject = db.subjects.findById(req.params.id);
    if (!subject) throw new HttpError(404, "Subject not found");
    db.subjects.delete(subject._id);
    return okMessage(res, 200, "Removed");
  }),
);

module.exports = router;
